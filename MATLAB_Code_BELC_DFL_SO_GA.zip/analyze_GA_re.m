% === Load dữ liệu nhiều run đã lưu ===
load('GA_results.mat','GA_results');   % GA_results là cell array

num_runs = numel(GA_results);    % số lần chạy GA
max_len  = max(cellfun(@length,GA_results));  % độ dài dài nhất

% === Ghép thành ma trận (đệm NaN nếu không bằng nhau) ===
F = nan(num_runs,max_len);
for i = 1:num_runs
    len = length(GA_results{i});
    F(i,1:len) = GA_results{i};
end

% === Tính chỉ số Repeatability & Sensitivity ===
final_values = nan(num_runs,1);
for i = 1:num_runs
    % lấy giá trị fitness cuối cùng (bỏ NaN)
    data = F(i,~isnan(F(i,:)));
    final_values(i) = data(end);
end

mean_final = mean(final_values);
std_final  = std(final_values);
cv_final   = std_final/mean_final;        % hệ số biến thiên (repeatability)
CI95_low  = mean_final - 1.96*std_final/sqrt(num_runs);
CI95_high = mean_final + 1.96*std_final/sqrt(num_runs);

% Sensitivity (ví dụ: độ biến thiên theo iteration)
avg_std_per_iter = nanmean(std(F,0,1,'omitnan'));  % trung bình std theo iteration

% === In kết quả ===
disp('--- Repeatability & Sensitivity ---');
fprintf('Mean final fitness = %.4f\n', mean_final);
fprintf('Std final fitness  = %.4f\n', std_final);
fprintf('CV final           = %.4f\n', cv_final);
fprintf('95%% CI = [%.4f , %.4f]\n', CI95_low, CI95_high);
fprintf('Avg sensitivity (std per iteration) = %.4f\n', avg_std_per_iter);

% === Nếu muốn lưu kết quả ra file để đọc sau ===
results.mean_final = mean_final;
results.std_final  = std_final;
results.cv_final   = cv_final;
results.CI95_low       = CI95_low;
results.CI95_high       = CI95_high;
results.avg_sens   = avg_std_per_iter;

save('GA_analysis.mat','F','results');
