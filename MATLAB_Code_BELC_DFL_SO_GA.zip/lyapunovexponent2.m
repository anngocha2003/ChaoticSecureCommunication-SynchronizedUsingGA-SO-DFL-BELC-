%% main_keyspace_estimation.m
% Ước lượng tỷ lệ hỗn loạn (f_i) cho từng tham số/điều kiện đầu
% và ước lượng key space hiệu dụng

clear all;
close all;
clc;

%% ==== THIẾT LẬP BAN ĐẦU ====
% Bộ tham số gốc (ví dụ bạn chọn)
fixed.A=1; 
fixed.B=1; 
fixed.C=1.5; 
fixed.D=26; 
fixed.E=0.7;
fixed.x0=2; 
fixed.y0=2; 
fixed.z0=2; 
fixed.w0=2;

% Tùy chọn quét
opts.h=0.001; 
opts.T=50;             % thời gian mô phỏng
opts.numSamples=50;    % số mẫu mỗi biến
opts.mode='grid';      % 'grid' hoặc 'mc'
opts.target='hyper';   % 'chaos' >=1 LE+ ; 'hyper' >=2 LE+

%% ==== QUÉT TỪNG BIẾN ====
% Khoảng khảo sát (ví dụ)
ranges.D  = [20 30];
ranges.E  = [0.5 1.0];
ranges.x0 = [-7 9];
ranges.z0 = [0 43];
ranges.y0 = [-20 23];
ranges.w0 = [-3 4];

% Ước lượng tỷ lệ hỗn loạn
f_D  = estimate_fraction_one_var('D', ranges.D, fixed, opts);
f_E  = estimate_fraction_one_var('E', ranges.E, fixed, opts);
f_x0 = estimate_fraction_one_var('x0', ranges.x0, fixed, opts);
f_y0 = estimate_fraction_one_var('y0', ranges.y0, fixed, opts);
f_z0 = estimate_fraction_one_var('z0', ranges.z0, fixed, opts);
f_w0 = estimate_fraction_one_var('w0', ranges.w0, fixed, opts);

fprintf('==== TỶ LỆ HỖN LOẠN (f_i) ====\n');
fprintf('f_D  = %.3f\n', f_D);
fprintf('f_E  = %.3f\n', f_E);
fprintf('f_x0 = %.3f\n', f_x0);
fprintf('f_y0 = %.3f\n', f_y0);
fprintf('f_z0 = %.3f\n', f_z0);
fprintf('f_w0 = %.3f\n', f_w0);

%% ==== KEY SPACE HIỆU DỤNG ====
% Giả sử 9 thành phần bí mật, mỗi cái float32 ≈ 23 bits
k_nominal = 9 * 23;

% cộng thêm log2(f_i)
adj = sum([log2(f_D), log2(f_E), log2(f_x0), log2(f_y0), log2(f_z0), log2(f_w0)]);
k_eff = k_nominal + adj;

fprintf('\n==== KEY SPACE ====\n');
fprintf('Nominal key space = %.1f bits\n', k_nominal);
fprintf('Effective key space ≈ %.1f bits\n', k_eff);

%% ==== HÀM PHỤ ====
function [LEs,count_pos] = lyap4d_lu(A,B,C,D,E, x0,y0,z0,w0, h, T)
    % Tính 4 mũ Lyapunov (Euler) và số lượng mũ dương
    N = round(T/h);
    X = zeros(4,N+1);
    X(:,1) = [x0;y0;z0;w0];
    for n=1:N
        x=X(1,n); y=X(2,n); z=X(3,n); w=X(4,n);
        dx = A*(y - x) + C*w;
        dy = D*x - x*z - y;
        dz = x*y - E*z;
        dw = -x - B*w;
        X(:,n+1) = X(:,n) + h*[dx;dy;dz;dw];
    end

    jacobian = @(x,y,z,w) [ ...
        1 - h*A,     h*A,         0,        h*C;
        h*(D - z),   1 - h,     -h*x,       0;
        h*y,         h*x,       1 - h*E,    0;
       -h,          -h,         0,         1 - h*B ];

    n0 = max(2, round(0.1*(N+1))); % bỏ transient

    Q = eye(4); S = zeros(4,1); steps = 0;
    for n=n0:(N+1)
        x=X(1,n); y=X(2,n); z=X(3,n); w=X(4,n);
        J = jacobian(x,y,z,w);
        Z = J*Q;
        [Q,R] = qr(Z);
        S = S + log(abs(diag(R)));
        steps = steps + 1;
    end
    LEs = S / (steps*h);
    LEs = sort(LEs,'descend');
    count_pos = sum(LEs > 1e-3);
end

function f = estimate_fraction_one_var(varname, range, fixed, opts)
    % Quét một biến, tính tỷ lệ hỗn loạn/hyperchaos
    if strcmpi(opts.mode,'grid')
        vals = linspace(range(1), range(2), opts.numSamples);
    else
        vals = range(1) + (range(2)-range(1))*rand(1,opts.numSamples);
    end

    ok = 0;
    for k=1:opts.numSamples
        S = fixed;
        S.(varname) = vals(k);
        [LEs,count_pos] = lyap4d_lu(S.A,S.B,S.C,S.D,S.E, ...
                                    S.x0,S.y0,S.z0,S.w0, ...
                                    opts.h, opts.T);
        want = false;
        if strcmpi(opts.target,'hyper')
            want = (count_pos >= 2);
        elseif strcmpi(opts.target,'chaos')
            want = (count_pos >= 1);
        end
        if want, ok = ok + 1; end
    end
    f = ok / opts.numSamples;
end
