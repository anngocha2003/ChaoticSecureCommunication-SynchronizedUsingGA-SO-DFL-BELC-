% Parameters
h = 0.001;            % Time step
T = 100;              % Total time
N = T / h;            % Number of steps

% Initial conditions
x0 = 0.15; y0 = 0.25; z0 = -0.5; w0 = -0.25;
X = zeros(4, N+1);
X(:,1) = [x0; y0; z0; w0];

% Simulate 4D Chaotic System
for n = 1:N
    x = X(1,n);
    y = X(2,n);
    z = X(3,n);
    w = X(4,n);

    dx = y - x + 1.5*w;
    dy = 26*x - x*z - y;
    dz = x*y - 0.7*z;
    dw = -x - y;

    X(:,n+1) = X(:,n) + h * [dx; dy; dz; dw];
end

% Define Jacobian Function
jacobian = @(x,y,z,w) [ ...
    1 - h,        h,         0,        1.5*h;
    h*(26 - z),   1 - h,     -h*x,     0;
    h*y,          h*x,       1 - 0.7*h, 0;
   -h,           -h,         0,        1 ];

% Lyapunov Exponent via QR
Q = eye(4);
LE_log = zeros(4, N+1);
for n = 2:N+1
    x = X(1,n);
    y = X(2,n);
    z = X(3,n);
    w = X(4,n);

    J = jacobian(x,y,z,w);
    Z = J * Q;
    [Q, R] = qr(Z);
    LE_log(:,n) = LE_log(:,n-1) + log(abs(diag(R)));
end

% Time and Lyapunov Exponent values
t = (0:N)*h;
LE_time = LE_log ./ (t + eps);  % Avoid divide by zero

% Final Lyapunov Exponents
L = LE_time(:,end);
L = sort(L,'descend');

% Fractal Dimension (Kaplan-Yorke)
s = 0; j = 0;
for i = 1:length(L)
    s = s + L(i);
    if s < 0
        break;
    end
    j = i;
end
D_KY = j + sum(L(1:j)) / abs(L(j+1));

% Final Equivalent Points (from last Q)
Q_final = Q;
lambda1 = Q_final(:,1);
lambda2 = Q_final(:,2);
lambda3 = Q_final(:,3);
lambda4 = Q_final(:,4);

% Display Results
fprintf('Lyapunov Exponents:\n');
fprintf('L1 = %.4f\nL2 = %.4f\nL3 = %.4f\nL4 = %.4f\n', L(1), L(2), L(3), L(4));
fprintf('\nFractal Dimension (Kaplan-Yorke): D_KY = %.4f\n', D_KY);

fprintf('\nEquivalent Points (λ vectors):\n');
fprintf('λ1 = [%.4f; %.4f; %.4f; %.4f]\n', lambda1);
fprintf('λ2 = [%.4f; %.4f; %.4f; %.4f]\n', lambda2);
fprintf('λ3 = [%.4f; %.4f; %.4f; %.4f]\n', lambda3);
fprintf('λ4 = [%.4f; %.4f; %.4f; %.4f]\n', lambda4);

% Plot Lyapunov Exponents over time
figure;
plot(t, LE_time(1,:), 'r', 'LineWidth', 1.5); hold on;
plot(t, LE_time(2,:), 'b', 'LineWidth', 1.5);
plot(t, LE_time(3,:), 'g', 'LineWidth', 1.5);
plot(t, LE_time(4,:), 'm', 'LineWidth', 1.5);
yline(0,'--k');
xlabel('Time (s)'); ylabel('Lyapunov Exponents');
title('Lyapunov Exponents of 4D Chaotic System');
legend('\itL_1','\itL_2','\itL_3','\itL_4');
grid on;
