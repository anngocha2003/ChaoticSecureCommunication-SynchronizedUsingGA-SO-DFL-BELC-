
%% chaos_esp32_network_sim.m
% Mô phỏng 3 ESP (A/B/C) với kênh speed và duty, mã hóa kiểu bạn đang dùng:
% value_enc = value + 500 + 5*round(xm(1)*10)/10
% Gói gửi kèm trạng thái hỗn loạn xm[0..3] (như trong firmware bạn đưa).
% Mạng được mô phỏng 2 hop (A->B, B->C) với trễ ngẫu nhiên, jitter, loss, out-of-order.
% Tính các metrics: p50/p95/p99 latency, jitter, loss %, encryption/ decryption delay,
% ổn định vòng kín (ISE, ITAE, ESS, overshoot, bandwidth ~ 0.35/t_r).
%
% Chạy: chỉ cần chạy file, các tham số ở mục "PARAMS".

clear; clc;

%% ================== PARAMS ==================
Tend_s    = 60;          % thời gian mô phỏng (s)
fs_ctrl   = 200;         % tần số vòng lặp điều khiển (Hz) ~ 200-400 Hz
Ts        = 1/fs_ctrl;   % bước lấy mẫu (s)

% Tham chiếu và plant đơn giản (để đo ổn định vòng kín)
ref_speed = 1000;        % rpm (ví dụ)
tau_p     = 0.08;        % hằng số thời gian plant (s)
ku        = 8;           % hệ số chuyển từ duty -> tốc độ
dist_amp  = 30;          % biên độ nhiễu (rpm)
dist_f    = 0.25;        % tần số nhiễu (Hz)

% Bộ điều khiển PI (ánh xạ code của bạn)
Kp = 0.1; Ki = 0.06;
duty_min = 30; duty_max = 150;

% Chaos (Liu 4D) bước Euler như firmware
h_sub = Ts;             % bước tích phân (có thể Ts/2 để bền số hơn)
xmA = [0.15;0.25;-0.5;-0.25];        % trạng thái master trên A (kênh speed)
% x0 = 0.15; y0 = 0.25; z0 = -0.5; w0 = -0.25;
xmB = [0;0;0;0];% master trên B (kênh duty)
% Slave không dùng đúng nghĩa (do packet gửi thẳng xm), giữ đây để mở rộng nếu cần
xsB = xmA; xsC = xmB;

% Mạng (ESP-NOW) — thông số trễ ~ microseconds (us)
A2B_mu_us  = 2500;  A2B_jit_us = 800;   % trung bình & jitter
B2C_mu_us  = 2500;  B2C_jit_us = 800;
p_loss     = 0.003;                   % 0.3% mất gói
p_ooo      = 0.001;                   % out-of-order nhỏ

% Thời gian mã hóa/giải mã (us), xấp xỉ từ firmware
enc_mu_us = 150;  enc_sig_us = 50;
dec_mu_us = 150;  dec_sig_us = 50;
belc_mu_us = 400; belc_sig_us = 150;   % tính điều khiển ở nút B

% Random seed để tái lập
rng(42);

%% ============== Tiện ích mô phỏng mạng ==============
function us = clip_us(x, lo)
    us = max(x, lo);
end

function v = enc_delay_us(mu,sig)
    v = max(mu + sig*randn, 30);
end

function v = dec_delay_us(mu,sig)
    v = max(mu + sig*randn, 30);
end

function v = belc_delay_us(mu,sig)
    v = max(mu + sig*randn, 80);
end

%% ============== Logger cấu trúc giống firmware ==============
% log table cho từng gói
logHop = strings(0,1);
logSeq = zeros(0,1);
logTx  = zeros(0,1);
logRx  = zeros(0,1);
logEnc = zeros(0,1);
logDec = zeros(0,1);

function append_log(hop, seq, ts_tx, ts_rx, t_enc_us, t_dec_us)
    % closure ghi vào base workspace
    assignin('base','logHop', [evalin('base','logHop'); string(hop)]);
    assignin('base','logSeq', [evalin('base','logSeq'); seq]);
    assignin('base','logTx',  [evalin('base','logTx');  ts_tx]);
    assignin('base','logRx',  [evalin('base','logRx');  ts_rx]);
    assignin('base','logEnc', [evalin('base','logEnc'); t_enc_us]);
    assignin('base','logDec', [evalin('base','logDec'); t_dec_us]);
end

%% ============== Hàm chaos Liu 4D (Euler, giống code) ==============
function x = liu4d_euler_step(x, h)
    xdot = [x(2) - x(1) + 1.5*x(4);
            26*x(1) - x(1)*x(3) - x(2);
            x(1)*x(2) - 0.7*x(3);
           -x(1) - x(4)];
    x = x + h*xdot;
end

%% ============== Hàm mã hóa/giải mã (theo code firmware) ==============
function y = chaos_encrypt(val, xm1)
    y = val + 500 + 5*round(xm1*10)/10;  % xm1 là x(1) – thành phần thứ nhất
end

function val = chaos_decrypt(y, xm1)
    val = y - 500 - 5*round(xm1*10)/10;
end

%% ============== Hàm thống kê mạng ==============
function S = net_stats(tbl)
    % lọc theo hop
    A2B = tbl(strcmp(tbl.hop,'A2B'),:);
    B2C = tbl(strcmp(tbl.hop,'B2C'),:);
    pct = @(x,p) prctile(x,p);
    S.A2B.p50 = pct(A2B.lat_us,50);
    S.A2B.p95 = pct(A2B.lat_us,95);
    S.A2B.p99 = pct(A2B.lat_us,99);
    S.B2C.p50 = pct(B2C.lat_us,50);
    S.B2C.p95 = pct(B2C.lat_us,95);
    S.B2C.p99 = pct(B2C.lat_us,99);
    S.A2B.jitter = std(A2B.lat_us);
    S.B2C.jitter = std(B2C.lat_us);
    % loss & out-of-order
    [S.A2B.loss_pct, S.A2B.ooo_cnt, S.A2B.mean_gap] = seq_stats(A2B.seq);
    [S.B2C.loss_pct, S.B2C.ooo_cnt, S.B2C.mean_gap] = seq_stats(B2C.seq);
    % enc/dec
    S.enc.p50 = pct(tbl.t_enc_us,50);  S.enc.p95 = pct(tbl.t_enc_us,95);
    S.dec.p50 = pct(tbl.t_dec_us,50);  S.dec.p95 = pct(tbl.t_dec_us,95);
end

function [loss_pct, ooo_cnt, mean_gap] = seq_stats(seq)
    if isempty(seq), loss_pct=0; ooo_cnt=0; mean_gap=0; return; end
    [seq_sorted, idx] = sort(seq);
    ooo_cnt = sum(diff(idx) < 0);
    gaps = diff(seq_sorted) - 1;
    loss = sum(gaps(gaps>0));
    denom = max(1, seq_sorted(end) - seq_sorted(1));
    loss_pct = 100*loss/denom;
    mean_gap = mean(max(gaps,0));
end

%% ============== Véc-tơ thời gian & biến trạng thái ==============
N = round(Tend_s/Ts)+1;
t = (0:N-1)*Ts;

% Plant & log
y = zeros(1,N);              % tốc độ thực tế (rpm)
u = zeros(1,N);              % duty áp dụng ở plant (sau khi C nhận & giải mã)
u_cmd = zeros(1,N);          % duty tính ở B (trước truyền)
i_err = 0;

% Chuỗi đã mã hoá
speed_enc = zeros(1,N);
duty_enc  = zeros(1,N);

% Chuỗi sau giải mã
speed_dec_B = zeros(1,N);
duty_dec_C  = zeros(1,N);

% Đếm seq theo hop
seqA = 0; seqB = 0;

% Hàng đợi sự kiện nhận gói (để mô phỏng trễ + out-of-order tự nhiên)
events = struct('time_us', {}, 'hop', {}, 'seq', {}, 'payload', {});

% helper: push event
function push_event(time_us, hop, seq, payload)
    ev.time_us = time_us; ev.hop = hop; ev.seq = seq; ev.payload = payload;
    assignin('base','events', [evalin('base','events'), ev]);
end

% helper: pop events whose time <= now
function [due, kept] = pop_due_events(now_us)
    evs = evalin('base','events');
    due = evs([evs.time_us] <= now_us);
    kept = evs([evs.time_us] > now_us);
    assignin('base','events', kept);
end

%% ================== MAIN LOOP ==================
now_us = 0;
for k = 2:N
    % ---- 1) Plant cập nhật (Euler rời rạc) ----
    d = dist_amp*sin(2*pi*dist_f*t(k-1));
    y(k) = y(k-1) + Ts*(-(y(k-1)) + ku*u(k-1))/tau_p + Ts*d;

    % ---- 2) Node A: encrypt speed & gửi A->B ----
    % Chaos step (A)
    xmA = liu4d_euler_step(xmA, h_sub);
    t_encA = enc_delay_us(enc_mu_us, enc_sig_us);
    speed_enc(k) = chaos_encrypt(y(k), xmA(1));

    % simulate send
    seqA = seqA + 1;
    ts_tx_A = now_us + t_encA;
    % network latency
    lat1 = clip_us(A2B_mu_us + A2B_jit_us*randn, 200);
    % loss?
    if rand > p_loss
        % out-of-order nhẹ: jitter âm cố định nhỏ
        if rand < p_ooo, lat1 = lat1 - 500; end
        ts_rx_B = ts_tx_A + lat1;
        % chuẩn bị payload giống firmware: {real, data, xm0..xm3, count}
        payload1.real = y(k);
        payload1.data = speed_enc(k);
        payload1.xm = xmA;
        payload1.count = k;
        push_event(ts_rx_B, 'A2B', seqA, payload1);
        append_log('A2B', seqA, ts_tx_A, ts_rx_B, t_encA, dec_delay_us(dec_mu_us,dec_sig_us));
    end

    % ---- 3) Deliver các gói đến hạn ----
    [due, kept] = pop_due_events(now_us);
    % xử lý từng gói đến hạn (có thể nhiều)
    for i=1:numel(due)
        ev = due(i);
        if ev.hop=="A2B"
            % ---- Node B nhận speed ----
            pkt = ev.payload;
            % ở firmware bạn: xm[] được gửi kèm -> giải mã trực tiếp
            t_decB = dec_delay_us(dec_mu_us,dec_sig_us);
            speed_dec = chaos_decrypt(pkt.data, pkt.xm(1));
            speed_dec_B(k) = speed_dec;

            % ---- Node B tính duty (BELC ~ PI) ----
            t_belc = belc_delay_us(belc_mu_us, belc_sig_us);
            e = ref_speed - speed_dec;
            i_err = i_err + e*Ts;
            duty_cmd = Kp*e + Ki*i_err;
            duty_cmd = max(duty_min, min(duty_max, duty_cmd));
            u_cmd(k) = duty_cmd;

            % ---- Node B mã hóa duty và gửi B->C ----
            xmB = liu4d_euler_step(xmB, h_sub);
            t_encB = enc_delay_us(enc_mu_us, enc_sig_us);
            duty_enc(k) = chaos_encrypt(duty_cmd, xmB(1));

            seqB = seqB + 1;
            ts_tx_B = ev.time_us + t_decB + t_belc + t_encB;
            lat2 = clip_us(B2C_mu_us + B2C_jit_us*randn, 200);
            if rand > p_loss
                if rand < p_ooo, lat2 = lat2 - 500; end
                ts_rx_C = ts_tx_B + lat2;
                payload2.data = duty_enc(k);
                payload2.xm   = xmB;
                payload2.count = k;
                push_event(ts_rx_C, 'B2C', seqB, payload2);
                append_log('B2C', seqB, ts_tx_B, ts_rx_C, t_encB, dec_delay_us(dec_mu_us,dec_sig_us));
            end
        elseif ev.hop=="B2C"
            % ---- Node C nhận duty ----
            pkt2 = ev.payload;
            duty_dec = chaos_decrypt(pkt2.data, pkt2.xm(1));
            duty_dec_C(k) = duty_dec;
            u(k) = duty_dec;  % áp vào plant ở tick kế tiếp
        end
    end

    % ---- 4) Cập nhật thời gian mô phỏng ----
    now_us = now_us + Ts*1e6;
    % giữ lại các event chưa đến hạn
    events = kept;
end

%% ================== HẬU XỬ LÝ ==================
% Lấp các mẫu chưa nhận bằng giá trị gần nhất (ZOH)
speed_dec_B = fillmissing(speed_dec_B,'previous');
duty_dec_C  = fillmissing(duty_dec_C,'previous');
u           = fillmissing(u,'previous');

% Bảng log
tbl = table(logHop, logSeq, logTx, logRx, logEnc, logDec, ...
    'VariableNames', {'hop','seq','ts_tx','ts_rx','t_enc_us','t_dec_us'});
tbl.lat_us = tbl.ts_rx - tbl.ts_tx;

% Thống kê mạng
S = net_stats(tbl);

% Chỉ số ổn định (so ref)
e = ref_speed - y;
dt = Ts;
ISE  = sum(e.^2)*dt;
ITAE = sum(t .* abs(e))*dt;
ESS  = abs(e(end));
overshoot = (max(y) - ref_speed) / ref_speed * 100;
% ước lượng bandwidth từ thời gian tăng
i10 = find(y >= ref_speed*0.1, 1, 'first');
i90 = find(y >= ref_speed*0.9, 1, 'first');
if ~isempty(i10) && ~isempty(i90)
    tr = t(i90) - t(i10);
    bw_hz = 0.35/max(tr,eps);
else
    tr = NaN; bw_hz = NaN;
end

%% ================== KẾT QUẢ ==================
disp('=== Thống kê mạng (us) ===');
disp(S);

fprintf('\n=== Ổn định vòng kín ===\n');
fprintf('ISE  = %.3f\n', ISE);
fprintf('ITAE = %.3f\n', ITAE);
fprintf('ESS  = %.3f rpm\n', ESS);
fprintf('Overshoot = %.2f %%\n', overshoot);
fprintf('Rise time tr = %.4f s,  BW ~= %.2f Hz\n', tr, bw_hz);

%% ================== VẼ (tùy chọn) ==================
figure; 
subplot(3,1,1);
plot(t,y,'LineWidth',1); hold on; yline(ref_speed,'--'); 
title('Tốc độ thực y(t)'); xlabel('s'); ylabel('rpm');
legend('y','ref'); grid on;

subplot(3,1,2);
plot(t,u_cmd,'LineWidth',1); hold on; plot(t,u,'--'); 
title('Duty tính ở B và duty áp vào plant'); xlabel('s'); ylabel('duty');
legend('u\_cmd (B)','u (C áp dụng)'); grid on;

subplot(3,1,3);
A2B = tbl(strcmp(tbl.hop,'A2B'),:);
B2C = tbl(strcmp(tbl.hop,'B2C'),:);
plot(A2B.ts_tx*1e-6, A2B.lat_us, '.'); hold on;
plot(B2C.ts_tx*1e-6, B2C.lat_us, '.');
title('Latency theo thời gian'); xlabel('s'); ylabel('us');
legend('A->B','B->C'); grid on;

%% ================== GỢI Ý SỬ DỤNG ==================
% - Điều chỉnh fs_ctrl, A2B_mu_us/B2C_mu_us, p_loss, enc/dec/belc để khớp lab.
% - Nếu muốn mô phỏng MQTT: tăng mu_us (VD 3-5 ms) và jitter.
% - Để test Ts biên: quét fs_ctrl = 200:50:400 và xem p95 latency vs Ts.
% - Muốn đồng bộ chaos theo kiểu master-slave thực: bỏ gửi xm[], để B/C tự chạy
%   và thêm luật đồng bộ; ở đây bám sát firmware hiện tại (gửi kèm xm).
