clc;
clear;
close all;

%tối giản bù nhiễu

%PLOT
step_num = 10000;

xm1_plot=zeros(1, step_num);
xm2_plot=zeros(1, step_num);
xm3_plot=zeros(1, step_num);
xm4_plot=zeros(1, step_num);

xs1_plot=zeros(1, step_num);
xs2_plot=zeros(1, step_num);
xs3_plot=zeros(1, step_num);
xs4_plot=zeros(1, step_num);

%Giá trị ban đầu 2 hệ
xm=[10, 10, 15, 20];
xs=[-10, -20, -30, -40];
xm_dot=zeros(size(xm));
xs_dot=zeros(size(xm));
h=0.001;

%Sai số
e=zeros(size(xm));

%Luật điều khiển
u=zeros(size(xm));

%Bộ điều khiển
Ne = 1; 
Nf = 4; 

vector_m = zeros(1,Ne);   
vector_v = ones(size(vector_m)); 
vector_Phi = ones(size(vector_m));
vector_w = zeros(Ne, 1);
matrix_q = zeros(Ne, Nf);
vector_I = zeros(Ne,1) + 1;

%%% BELC
baseVector=cell(numel(xm), 1);
m_a=baseVector;
v_a=baseVector;
Phi_a=baseVector;
w_a=baseVector;
q_a=baseVector;
I_a=baseVector;

%GA
pop = 22;   %số cá thể   
n_ga = 6;

population=zeros(pop, n_ga);

sum_e=0;

for i = 1:numel(xm)
    m_a{i} = vector_m;
    v_a{i} = vector_v;
    Phi_a{i}=vector_Phi;
    w_a{i}=vector_w;
    q_a{i}=matrix_q;
    I_a{i}=vector_I;
end

m_o=m_a;
v_o=v_a;
Phi_o=Phi_a;
w_o=w_a;
q_o = q_a; 
I_o=I_a;

a = zeros(size(xm));

% Lưu lịch sử các biến
m_a_hist = cell(4,1);  % 4 biến trạng thái
m_o_hist = cell(4,1);
v_a_hist = cell(4,1);
v_o_hist = cell(4,1);
Phi_a_hist = cell(4,1);
Phi_o_hist = cell(4,1);
w_a_hist = cell(4,1);
w_o_hist = cell(4,1);
q_a_hist = cell(4,1);
q_o_hist = cell(4,1);
I_a_hist = cell(4,1);
I_o_hist = cell(4,1);

for i = 1:4
    m_a_hist{i} = zeros(step_num, length(m_a{i}));
    m_o_hist{i} = zeros(step_num, length(m_o{i}));
    v_a_hist{i} = zeros(step_num, length(v_a{i}));
    v_o_hist{i} = zeros(step_num, length(v_o{i}));
    Phi_a_hist{i} = zeros(step_num, length(Phi_a{i}));
    Phi_o_hist{i} = zeros(step_num, length(Phi_o{i}));
    w_a_hist{i} = zeros(step_num, length(w_a{i}));
    w_o_hist{i} = zeros(step_num, length(w_o{i}));
    q_a_hist{i} = zeros(step_num, numel(q_a{i}));
    q_o_hist{i} = zeros(step_num, numel(q_o{i}));
    I_a_hist{i} = zeros(step_num, length(I_a{i}));
    I_o_hist{i} = zeros(step_num, length(I_o{i}));
end

for step=1:step_num
    %PLOT
    xm1_plot(step)=xm(1);
    xm2_plot(step)=xm(2);
    xm3_plot(step)=xm(3);
    xm4_plot(step)=xm(4);
    
    xs1_plot(step)=xs(1);
    xs2_plot(step)=xs(2);
    xs3_plot(step)=xs(3);
    xs4_plot(step)=xs(4);

    % Luu loi dong bo theo thoi gian (sau moi buoc cap nhat xs)
    e_hist = zeros(step_num, 4);     % lỗi từng biến tại mỗi step
    e_norm_hist = zeros(step_num,1); % lỗi tổng (norm-2) tại mỗi step
        
    %MASTER SYSTEM
    xm_dot(1) = xm(2)-xm(1)+1.5*xm(4);
    xm_dot(2) = 26*xm(1)-xm(1)*xm(3)-xm(2);
    xm_dot(3) = xm(1)*xm(2)-0.7*xm(3);
    xm_dot(4) = -xm(1)-xm(4);

    xm = xm + xm_dot*h;

    %CONTROLLER
    e = xm - xs;
    
    xs_dot(1) = xs(2)-xs(1)+1.5*xs(4);
    xs_dot(2) = 26*xs(1)-xs(1)*xs(3)-xs(2);
    xs_dot(3) = xs(1)*xs(2)-0.7*xs(3);   
    xs_dot(4) = -xs(1)-xs(4);

    if step==5
        population = initial_pop(e, u, a, m_a, m_o, v_a, v_o, q_a, q_o, Phi_a, Phi_o, ...
            w_a, w_o, pop, n_ga, xm, xs, xs_dot);
    end
    
    [u, a, m_a, m_o, v_a, v_o, q_a, q_o, Phi_a, Phi_o, w_a, w_o, I_a, I_o, population] = controller(e, u, a, m_a, m_o, ...
    v_a, v_o, q_a, q_o, Phi_a, Phi_o, w_a, w_o, I_a, I_o, population, pop, n_ga, xm, xs, xs_dot, step);

    %SLAVE SYSTEM 
    xs_dot(1) = xs(2)-xs(1)+1.5*xs(4);
    xs_dot(2) = 26*xs(1)-xs(1)*xs(3)-xs(2);
    xs_dot(3) = xs(1)*xs(2)-0.7*xs(3);   
    xs_dot(4) = -xs(1)-xs(4);

    xs = xs + (xs_dot+u)*h;

    % Ghi nhan loi dong bo sau khi cap nhat xs
    e_post = xm - xs;                 % lỗi sau khi điều khiển áp dụng
    e_hist(step, :) = e_post;         % lưu từng biến
    e_norm_hist(step, 1) = norm(e_post, 2); % lưu lỗi tổng thể


    for i = 1:4
    m_a_hist{i}(step,1:length(m_a{i})) = m_a{i};
    m_o_hist{i}(step,1:length(m_o{i})) = m_o{i};
    v_a_hist{i}(step,1:length(v_a{i})) = v_a{i};
    v_o_hist{i}(step,1:length(v_o{i})) = v_o{i};
    Phi_a_hist{i}(step,1:length(Phi_a{i})) = Phi_a{i};
    Phi_o_hist{i}(step,1:length(Phi_o{i})) = Phi_o{i};
    w_a_hist{i}(step,1:length(w_a{i})) = w_a{i};
    w_o_hist{i}(step,1:length(w_o{i})) = w_o{i};
    q_a_hist{i}(step,1:numel(q_a{i})) = q_a{i}(:)';
    q_o_hist{i}(step,1:numel(q_o{i})) = q_o{i}(:)';
    I_a_hist{i}(step,1:length(I_a{i})) = I_a{i};
    I_o_hist{i}(step,1:length(I_o{i})) = I_o{i};
    end

    disp(step)
    sum_e=sum_e+sum(abs(e));
end

disp(sum_e)

% TINH ISE / IAE / ITAE
% ===========================
t = (1:step_num)' * h;  % trục thời gian (s)

% Theo từng biến (1..4)
ISE_each  = trapz(t, e_hist.^2);                 % 1x4
IAE_each  = trapz(t, abs(e_hist));               % 1x4
% ITAE với nhân thời gian
try
    ITAE_each = trapz(t, t .* abs(e_hist));      % 1x4 (MATLAB mới hỗ trợ implicit expansion)
catch
    ITAE_each = trapz(t, bsxfun(@times, t, abs(e_hist))); % fallback cho MATLAB cũ
end

% Tổng thể (dùng norm-2)
ISE_all  = trapz(t, e_norm_hist.^2);
IAE_all  = trapz(t, abs(e_norm_hist));
ITAE_all = trapz(t, t .* abs(e_norm_hist));

fprintf('\n===== CHI SO CHAT LUONG DONG BO =====\n');
fprintf('Theo tung bien (1..4):\n');
fprintf('  ISE  = [%.6g  %.6g  %.6g  %.6g]\n', ISE_each);
fprintf('  IAE  = [%.6g  %.6g  %.6g  %.6g]\n', IAE_each);
fprintf('  ITAE = [%.6g  %.6g  %.6g  %.6g]\n', ITAE_each);
fprintf('Tong the (norm-2 loi):\n');
fprintf('  ISE_all  = %.6g\n', ISE_all);
fprintf('  IAE_all  = %.6g\n', IAE_all);
fprintf('  ITAE_all = %.6g\n\n', ITAE_all);

%PLOT
figure;
titles = {'xm1 và xs1', 'xm2 và xs2', 'xm3 và xs3', 'xm4 và xs4'};
vars = {xm1_plot, xs1_plot; 
        xm2_plot, xs2_plot; 
        xm3_plot, xs3_plot; 
        xm4_plot, xs4_plot};
labels = {'xm', 'xs'};

for i = 1:4
    subplot(2, 2, i);
    plot(1:step_num, vars{i, 1}, 'b-', 'DisplayName', labels{1}, 'LineWidth', 0.5);
    hold on;
    plot(1:step_num, vars{i, 2}, 'r-', 'DisplayName', labels{2}, 'LineWidth', 0.5);
    hold off;
    
    xlabel('Step Number', 'FontSize', 10, 'FontWeight', 'bold');
    ylabel('Value', 'FontSize', 10, 'FontWeight', 'bold');
    title(titles{i}, 'FontSize', 12, 'FontWeight', 'bold');
    legend('Location', 'Best', 'FontSize', 8);
    grid on;
    set(gca, 'FontSize', 8);
end

vars = {'m_a', 'm_o', 'v_a', 'v_o', 'Phi_a', 'Phi_o', ...
        'w_a', 'w_o', 'q_a', 'q_o', 'I_a', 'I_o'};

for v = 1:length(vars)
    figure;
    for i = 1:4
        subplot(2,2,i);
        eval(sprintf('plot(%s_hist{i});', vars{v}));
        title(sprintf('%s biến %d', vars{v}, i));
        xlabel('Step'); ylabel('Giá trị');
    end
end


function population = initial_pop(e, u, a, m_a, m_o, v_a, v_o, q_a, q_o, Phi_a, Phi_o, w_a, w_o, m, n, xm, xs, xs_dot)
    population=zeros(m,n);

    f=cell(1,4);
    for i=1:4
        f{i} = [1; e(i); sin(e(i)); cos(e(i))];
    end

    for i=1:m
        pop = create_population(m, n);
        [pop, ~] = sort_fitness_population(e, u, a, m_a, m_o, v_a, v_o, q_a, q_o, Phi_a, Phi_o, w_a, w_o, f, pop, m, xm, xs, xs_dot);
        population(i,:) = pop(m,:);
    end
    
    [population, ~] = sort_fitness_population(e, u, a, m_a, m_o, v_a, v_o, q_a, q_o, Phi_a, Phi_o, w_a, w_o, f, population, m, xm, xs, xs_dot);
end

function [u, a, m_a, m_o, v_a, v_o, q_a, q_o, Phi_a, Phi_o, w_a, w_o, I_a, I_o, population] = controller(e, u, a, m_a, m_o, ...
    v_a, v_o, q_a, q_o, Phi_a, Phi_o, w_a, w_o, I_a, I_o, population, pop, n_ga, xm, xs, xs_dot, step)

    for i=1:4
        [m_a{i}, m_o{i}, v_a{i}, v_o{i}, Phi_a{i}, Phi_o{i}, w_a{i}, w_o{i}, q_a{i}, q_o{i}, I_a{i}, I_o{i}] = SO(e(i), m_a{i}, m_o{i}, v_a{i}, ...
            v_o{i}, Phi_a{i}, Phi_o{i}, w_a{i}, w_o{i}, q_a{i}, q_o{i}, I_a{i}, I_o{i});
    end

    if step>5     
        e_check=zeros(1,4);
        
        for i=1:4
            e_check(i) = check(e(i), u(i), a(i), w_a{i}, w_o{i}, m_a{i}, m_o{i}, Phi_a{i}, Phi_o{i}, v_a{i}, v_o{i}, ...
                q_a{i}, q_o{i}, xm(i), xs(i), xs_dot(i), population, pop);
        end
        
        population = GA(e, e_check, u, a, m_a, m_o, v_a, v_o, q_a, q_o, Phi_a, Phi_o, w_a, w_o, population, pop, n_ga, xm, xs, xs_dot);
    end

    for i=1:4
        [u(i), a(i), w_a{i}, w_o{i}, m_a{i}, m_o{i}, Phi_a{i}, Phi_o{i}, v_a{i}, v_o{i}, q_a{i}, q_o{i}] = BELC(e(i), ...
         u(i), a(i), w_a{i}, w_o{i}, m_a{i}, m_o{i}, Phi_a{i}, Phi_o{i}, v_a{i}, v_o{i}, q_a{i}, q_o{i}, population, pop);
    end
end

function e_check = check(e, u, a, w_a, w_o, m_a, m_o, Phi_a, Phi_o, v_a, v_o, q_a, q_o, xm, xs, xs_dot, population, pop)
    eta_m_a=population(pop, 1);
    eta_m_o=population(pop, 2);
    eta_v_a=population(pop, 3);
    eta_v_o=population(pop, 4);
    eta_q_a=population(pop, 5);
    eta_q_o=population(pop, 6);
    eq=100;
    
    %Function
    f = [1; e; sin(e); cos(e)];

    %%%%% Update Parameters
    % Update mean
    delta_m_a = eta_m_a  * w_a' .* Phi_a .* 2.*(e-m_a)./v_a.^2;
    delta_m_o = -eta_m_o  * w_o' .* Phi_o .* 2.*(e-m_o)./v_o.^2;

    % Update variance
    delta_v_a = eta_v_a * w_a' .* Phi_a .* 2.*(e-m_a).^2./v_a.^3;
    delta_v_o = -eta_v_o * w_o' .* Phi_o .* 2.*(e-m_o).^2./v_o.^3;

    % Update weight
    dq = eq*e+u;
    delta_q_a = eta_q_a*max(0,dq-a)*(f*Phi_a)';
    delta_q_o = eta_q_o*(u-dq)*(f*Phi_o)';

    m_a_check=m_a+delta_m_a;
    m_o_check=m_o+delta_m_o;
    v_a_check=v_a+delta_v_a;
    v_o_check=v_o+delta_v_o;
    q_a_check=q_a+delta_q_a;
    q_o_check=q_o+delta_q_o;

    %Weight
    w_a_check = q_a_check*f;
    w_o_check = q_o_check*f;

    %Gauss function
    Phi_a_check = exp(-(e-m_a_check).^2./v_a_check.^2);
    Phi_o_check = exp(-(e-m_o_check).^2./v_o_check.^2);

    %Layer 2
    a_check = Phi_a_check*w_a_check;
    o_check = Phi_o_check*w_o_check;

    %Control law
    u_check = a_check - o_check; 

    xs_check = xs + (xs_dot+u_check)*0.001;

    e_check=xm-xs_check;
end

function population = GA(e, e_check, u, a, m_a, m_o, v_a, v_o, q_a, q_o, Phi_a, Phi_o, w_a, w_o, population, pop, ~, xm, xs, xs_dot) 
    %Function  
    f=cell(1,4);
    for i=1:4
        f{i} = [1; e(i); sin(e(i)); cos(e(i))];
    end
    
    e_threshhold=0.3;
    ga_time=100;
    time_ga=0;
   
    if e_threshhold < sum(abs(e_check))
        while(time_ga<ga_time)
            time_ga=time_ga+1;
            population = create_new_population(population, pop);
            [population, max_fitness] = sort_fitness_population(e, u, a, m_a, m_o, v_a, v_o, q_a, q_o, Phi_a, Phi_o, ...
            w_a, w_o, f, population, pop, xm, xs, xs_dot);

            if max_fitness>1/(sum(abs(e_check))+1)
                break;
            end
        end
    end
end

function [population, max_fitness] = sort_fitness_population(e, u, a, m_a, m_o, v_a, v_o, q_a, q_o, Phi_a, Phi_o, ...
    w_a, w_o, f, population, pop, xm, xs, xs_dot)
    fitness_value=zeros(pop,1);
    u_ga=zeros(1,4);
    h=0.001;

    for gen=1:pop
        eta_m_a=population(gen, 1);
        eta_m_o=population(gen, 2);
        eta_v_a=population(gen, 3);
        eta_v_o=population(gen, 4);
        eta_q_a=population(gen, 5);
        eta_q_o=population(gen, 6);
        eq=100;
        for i=1:4 
            %%%%% Update Parameters
            % Update mean
            delta_m_a = eta_m_a * w_a{i}' .* Phi_a{i} .* 2.*(e(i)-m_a{i})./v_a{i}.^2;
            delta_m_o = -eta_m_o * w_o{i}' .* Phi_o{i}.* 2.*(e(i)-m_o{i})./v_o{i}.^2;
    
            % Update variance
            delta_v_a = eta_v_a * w_a{i}' .* Phi_a{i} .* 2.*(e(i)-m_a{i}).^2./v_a{i}.^3;
            delta_v_o = -eta_v_o * w_o{i}' .* Phi_o{i}.* 2.*(e(i)-m_o{i}).^2./v_o{i}.^3;
    
            % Update weight
            dq = eq*e(i)+u(i);
            delta_q_a = eta_q_a*max(0,dq-a(i))*(f{i}*Phi_a{i})';
            delta_q_o = eta_q_o*(u(i)-dq)*(f{i}*Phi_o{i})';
    
            m_a_ga=m_a{i}+delta_m_a;
            m_o_ga=m_o{i}+delta_m_o;
            v_a_ga=v_a{i}+delta_v_a;
            v_o_ga=v_o{i}+delta_v_o;
            q_a_ga=q_a{i}+delta_q_a;
            q_o_ga=q_o{i}+delta_q_o;
    
            %Weight
            w_a_ga = q_a_ga*f{i};
            w_o_ga = q_o_ga*f{i};
    
            %Gauss function
            Phi_a_ga = exp(-(e(i)-m_a_ga).^2./v_a_ga.^2);
            Phi_o_ga = exp(-(e(i)-m_o_ga).^2./v_o_ga.^2);
    
            %Layer 2
            a_ga = Phi_a_ga*w_a_ga;
            o_ga = Phi_o_ga*w_o_ga;
    
            %Control law
            u_ga(i) = a_ga - o_ga;   
        end
        
        %SLAVE SYSTEM 
        xs_ga = xs + (xs_dot+u_ga)*h;

        e_ga=xm-xs_ga;

        fitness_value(gen) = 1/(sum(abs(e_ga))+1);
    end
    max_fitness=max(fitness_value);
    population = sort_function(population, fitness_value);
end

function [u, a, w_a, w_o, m_a, m_o, Phi_a, Phi_o, v_a, v_o, q_a, q_o] = BELC(e, u, a, w_a, w_o, m_a, m_o, Phi_a, Phi_o, v_a, v_o, ...
    q_a, q_o, population, pop)
    eta_m_a=population(pop, 1);
    eta_m_o=population(pop, 2);
    eta_v_a=population(pop, 3);
    eta_v_o=population(pop, 4);
    eta_q_a=population(pop, 5);
    eta_q_o=population(pop, 6);
    eq=100;

    %Function
    f = [1; e; sin(e); cos(e)]; 

    %%%%% Update Parameters
    % Update mean
    delta_m_a = eta_m_a  * w_a' .* Phi_a .* 2.*(e-m_a)./v_a.^2;
    delta_m_o = -eta_m_o  * w_o' .* Phi_o .* 2.*(e-m_o)./v_o.^2;

    % Update variance
    delta_v_a = eta_v_a * w_a' .* Phi_a .* 2.*(e-m_a).^2./v_a.^3;
    delta_v_o = -eta_v_o * w_o' .* Phi_o .* 2.*(e-m_o).^2./v_o.^3;

    % Update weight
    dq = eq*e+u;
    delta_q_a = eta_q_a*max(0,dq-a)*(f*Phi_a)';
    delta_q_o = eta_q_o*(u-dq)*(f*Phi_o)';
    
    m_a=m_a+delta_m_a;
    m_o=m_o+delta_m_o;
    v_a=v_a+delta_v_a;
    v_o=v_o+delta_v_o;
    q_a=q_a+delta_q_a;
    q_o=q_o+delta_q_o;
   
    %Weight
    w_a = q_a*f;
    w_o = q_o*f;

    %Gauss function
    Phi_a = exp(-(e-m_a).^2./v_a.^2);
    Phi_o = exp(-(e-m_o).^2./v_o.^2);

    %Layer 2
    a = Phi_a*w_a;
    o = Phi_o*w_o;
    
    %Control law
    u = a-o; 
end

function [m_a, m_o, v_a, v_o, Phi_a, Phi_o, w_a, w_o, q_a, q_o, I_a, I_o] = SO(e, m_a, m_o, v_a, v_o, Phi_a, Phi_o, w_a, w_o, q_a, q_o, I_a, I_o)
    % % Self Organizing
    T_i = 0.7;
    T_d1 = 0.7;
    T_d2 = 0.1;
    Tau_1 = 100;
    Tau_2 = 10; 
    vectorq = zeros(1, 4);
    % Neural increasing
    % a
    max_Phi_a = max(Phi_a);
    if (max_Phi_a<T_i)
        m_a = [m_a e];
        v_a = [v_a sum(v_a)/numel(v_a)];
        Phi_a = [Phi_a 1];
        w_a = [w_a; 1];
        q_a = [q_a; vectorq];
        I_a = [I_a; 1];
    end

    % o
    max_Phi_o = max(Phi_o);
    if (max_Phi_o<T_i)
        m_o = [m_o e];
        v_o = [v_o sum(v_o)/numel(v_o)];
        Phi_o = [Phi_o 1];
        w_o = [w_o; 1];
        q_o = [q_o; vectorq];
        I_o = [I_o; 1];
    end

    % Neural decreasing
    % a
    i = 1;
    while i <= numel(Phi_a)
        if Phi_a(i) < T_d1
            I_a(i) = I_a(i)*exp(-(1-Phi_a(i))/Tau_1);
        else
            I_a(i) = I_a(i)*(2-exp(-Phi_a(i)*(1-I_a(i))/Tau_2));
        end
        if I_a(i) < T_d2
            m_a = [m_a(1:(i-1)) m_a((i+1):numel(I_a))];
            v_a = [v_a(1:(i-1)) v_a((i+1):numel(I_a))];
            Phi_a = [Phi_a(1:(i-1)) Phi_a((i+1):numel(I_a))];
            w_a = [w_a(1:(i-1)); w_a((i+1):numel(I_a))];
            q_a = [q_a(1:(i-1),:); q_a((i+1):numel(I_a),:)];
            I_a = [I_a(1:(i-1)); I_a((i+1):numel(I_a))];
            i = i-1;
        end
        i = i+1;
    end

    % o
    i = 1;
    while i <= numel(Phi_o)
        if Phi_o(i) < T_d1
            I_o(i) = I_o(i)*exp(-(1-Phi_o(i))/Tau_1);
        else
            I_o(i) = I_o(i)*(2-exp(-Phi_o(i)*(1-I_o(i))/Tau_2));
        end
        if I_o(i) < T_d2
            m_o = [m_o(1:(i-1)) m_o((i+1):numel(I_o))];
            v_o = [v_o(1:(i-1)) v_o((i+1):numel(I_o))];
            Phi_o = [Phi_o(1:(i-1)) Phi_o((i+1):numel(I_o))];
            w_o = [w_o(1:(i-1)); w_o((i+1):numel(I_o))];
            q_o = [q_o(1:(i-1),:); q_o((i+1):numel(I_o),:)];
            I_o = [I_o(1:(i-1)); I_o((i+1):numel(I_o))];
            i = i-1;
        end
        i = i+1; 
    end
end

%%%GA
function result = create_gen(max_val, min_val) %khởi tạo gen
    result=10^(min_val + (max_val - min_val) * rand());   
end

function sorted_population = sort_function(population, fitness_value)   %sắp xếp quần thể theo chiều tăng dần độ thích nghi từng cá thể
    population_with_fitness = [fitness_value population];
    sorted_population_with_fitness = sortrows(population_with_fitness, 1);
    sorted_population = sorted_population_with_fitness(:, 2:end);
end

function individual_s = selection(sorted_population, m)   %lựa chọn cá thể
    index1=randi([1, m]);
    while true
        index2=randi([1, m]);
        if index1~=index2
            break
        end
    end

    individual_s = sorted_population(index1, :);

    if index2 > index1
        individual_s = sorted_population(index2, :);
    end
end

function [individual1_new, individual2_new] = crossover(individual1, individual2)   %lai ghép
    crossover_rate=0.9;
    individual1_new=individual1;
    individual2_new=individual2;
    for i=1:6
        if rand < crossover_rate
            individual1_new(i)=individual2(i);
            individual2_new(i)=individual1(i);
        else
            individual1_new(i)=individual1(i);
            individual2_new(i)=individual2(i);
        end
    end
end

function result = create_population(m, n)  %khởi tạo quần thể
    result = zeros(m,n);
    for i=1:m
        for j=1:n
            result(i,j)=create_gen(1, -7); 
        end 
    end
end

function individual_m = mutate(individual)    
    individual_m=individual;
    mutation_rate=0.1;

    for i=1:6
        if rand < mutation_rate
            individual_m(i) = create_gen(1, -7);
        else
            individual_m(i) = individual(i);
        end
    end
end

function new_population= create_new_population(old_population, m)  
    etilism = 2;
    new_population=old_population;
    for i=1:2:m-etilism
        individual_s1 = selection(old_population, m);  
        individual_s2 = selection(old_population, m);

        [individual_c1, individual_c2] = crossover(individual_s1, individual_s2);

        individual_m1 = mutate(individual_c1);
        individual_m2 = mutate(individual_c2);

        new_population(i,:)=individual_m1;
        new_population(i+1,:)=individual_m2;
    end 
end































