%% === PHÂN TÍCH NGẪU NHIÊN CHO KEYSTREAM HỖN LOẠN ===
% File Excel chứa dữ liệu keystream
filename = 'hyper4d_states_1.xlsx';   % đổi tên file bạn lưu
range = 'F2:F15002';           % cột chứa dữ liệu xm (hoặc C2:C10001 cho xs)

% Đọc dữ liệu (giả sử là số thực hoặc byte)
data = xlsread(filename, range);
N = length(data);

% Nếu dữ liệu là số thực => lượng tử hóa thành byte (0-255)
if ~all(data == floor(data))
    % scale về [0,255]
    dmin = min(data); dmax = max(data);
    data_norm = uint8( floor( 255*(data-dmin)/(dmax-dmin) ) );
else
    data_norm = uint8(data);
end

%% Tính histogram phân bố
[counts, edges] = histcounts(double(data_norm), 0:256);
p = counts / sum(counts);

%% Shannon entropy (bits/byte)
sh_entropy = -nansum(p .* log2(p));

%% Min-entropy
p_max = max(p);
min_entropy = -log2(p_max);

%% Autocorrelation (chuẩn hóa)
data_zm = double(data_norm) - mean(double(data_norm)); % zero-mean
acf = xcorr(data_zm, 'coeff');   % autocorrelation normalized
acf_mid = ceil(length(acf)/2);
acf_peaks = abs(acf([1:acf_mid-1, acf_mid+1:end]));
max_acf = max(acf_peaks);

% Ngưỡng thống kê (95%)
threshold = 1.96/sqrt(N);

%% Spectral Flatness Measure (SFM)
X = abs(fft(data_zm));
X = X(2:floor(N/2)); % bỏ DC và chỉ lấy nửa phổ
gm = exp(mean(log(X+eps))); % geometric mean
am = mean(X);                % arithmetic mean
sfm = gm / am;

%% Hiển thị kết quả
fprintf('=== KẾT QUẢ ĐÁNH GIÁ KEYSTREAM ===\n');
fprintf('Shannon entropy     = %.4f bits/byte\n', sh_entropy);
fprintf('Min-entropy         = %.4f bits/byte\n', min_entropy);
fprintf('Max autocorr (|τ|>0)= %.4f (ngưỡng 95%% ~ %.4f)\n', max_acf, threshold);
fprintf('Spectral flatness   = %.4f (tiệm cận 1 là tốt)\n', sfm);

% Kiểm tra số mức khác nhau (nếu chỉ 2 chữ số sẽ rất ít mức)
num_levels = numel(unique(round(data, 2)));
fprintf('Num Levels  = %.4f \n', num_levels);
