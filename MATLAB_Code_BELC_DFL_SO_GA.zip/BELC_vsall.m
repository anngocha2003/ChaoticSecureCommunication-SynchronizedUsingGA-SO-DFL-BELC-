clc;
clear;
close all;

%PLOT
% Tham số mô phỏng BELC
time=10;
time_step = 0.001;
step_num = time/time_step;   %%số bước nhảy
t         = (0:step_num-1) * time_step;   

% Tham số mô phỏng SMC 
t_total_smc = 10;     
h_smc = 1e-3;              
N_smc = round(t_total_smc/h_smc);
time_smc = (0:N_smc-1)*h_smc;

% Tham số mô phỏng PID
T_end_pid   = 10;              % [s] tổng thời gian
h_pid       = 1e-3;            % [s] bước mô phỏng (Euler tiến)
N_pid       = round(T_end_pid/h_pid);
t_pid       = (0:N_pid-1)*h_pid;

xm1_plot=zeros(1, step_num);
xm2_plot=zeros(1, step_num);
xm3_plot=zeros(1, step_num);
xm4_plot=zeros(1, step_num);

xs1_plot=zeros(1, step_num);
xs2_plot=zeros(1, step_num);
xs3_plot=zeros(1, step_num);
xs4_plot=zeros(1, step_num);

xs1_plot_dob=zeros(1, step_num);
xs2_plot_dob=zeros(1, step_num);
xs3_plot_dob=zeros(1, step_num);
xs4_plot_dob=zeros(1, step_num);

e1_plot=zeros(1, step_num);
e2_plot=zeros(1, step_num);
e3_plot=zeros(1, step_num);
e4_plot=zeros(1, step_num);

noise1_plot=zeros(1, step_num);
noise2_plot=zeros(1, step_num);
noise3_plot=zeros(1, step_num);
noise4_plot=zeros(1, step_num);

d_hat1_plot=zeros(1, step_num);
d_hat2_plot=zeros(1, step_num);
d_hat3_plot=zeros(1, step_num);
d_hat4_plot=zeros(1, step_num);

%Giá trị ban đầu 2 hệ
xm=[2, 2, 2, 2];
xs=[0, 0, 0, 0];
xm_dot=zeros(size(xm));
xs_dot=zeros(size(xm));
h=0.001;

%Sai số
e=zeros(size(xm));

%Luật điều khiển
u=zeros(size(xm));

%Bộ điều khiển
Ne = 10; 
Nf = 4; 

vector_m = zeros(1,Ne);   
vector_v = ones(size(vector_m)); 
vector_Phi = ones(size(vector_m));
vector_w = zeros(Ne, 1);
matrix_q = zeros(Ne, Nf);
vector_I = zeros(Ne,1) + 1;

%% BELC
baseVector=cell(numel(xm), 1);
m_a=baseVector;
v_a=baseVector;
Phi_a=baseVector;
w_a=baseVector;
q_a=baseVector;
I_a=baseVector;

for i = 1:numel(xm)
    m_a{i} = vector_m;
    v_a{i} = vector_v;
    Phi_a{i}=vector_Phi;
    w_a{i}=vector_w;
    q_a{i}=matrix_q;
    I_a{i}=vector_I;
end

m_o=m_a;
v_o=v_a;
Phi_o=Phi_a;
w_o=w_a;
q_o = q_a; 
I_o=I_a;

a = zeros(size(xm));

%% GA
pop = 22;   %số cá thể   
n_ga = 6;

population=zeros(pop, n_ga);

sum_e=0;
e_plot=zeros(size(xm4_plot));

noise=zeros(size(xm));
d_hat=zeros(size(xm));

global best_fitness_ga_all
best_fitness_ga_all = [];


%% ---------------------- Tham số mô phỏng & hệ TS ----------------------------
alpha_pid   = 0.25;            % tham số trong động lực
x_min_pid   = 20;              % biên min cho luật fuzzy
x_max_pid   = 32;              % biên max cho luật fuzzy

xm0_pid     = [ 0.0; 0.0; 0.0; 0.0];    % Master initial state
xs0_pid     = [ 2.0;-1.0; 1.0; 0.5];    % Slave initial state

u_max_pid   = 50;              % giới hạn điều khiển
use_sat_pid = true;            % bật giới hạn

w_err_pid   = [1, 1, 1, 1]';   % trọng số lỗi

%% ---------------------- Cấu hình PID PSO ----------------------------------------
dim_pid      = 3;
pop_size_pid = 30;
max_iter_pid = 80;

lb_pid = [  0,  0,  0];
ub_pid = [ 50, 50, 10];

w_inertia_pid = 0.72;
c1_pid        = 1.42;
c2_pid        = 1.42;

pos_pid = rand(pop_size_pid, dim_pid).*(ub_pid - lb_pid) + lb_pid;
vel_pid = zeros(pop_size_pid, dim_pid);

J_pid  = zeros(pop_size_pid,1);
for i = 1:pop_size_pid
    J_pid(i) = cost_fun_pid(pos_pid(i,:), xm0_pid, xs0_pid, ...
        N_pid, h_pid, alpha_pid, x_min_pid, x_max_pid, ...
        w_err_pid, u_max_pid, use_sat_pid);
end

pbest_pid     = pos_pid;
pbest_val_pid = J_pid;
[gbest_val_pid, idx_pid] = min(J_pid);
gbest_pid     = pos_pid(idx_pid,:);

fprintf('PSO start: J0 = %.4g, at [%g %g %g]\n', ...
    gbest_val_pid, gbest_pid);

%% ---------------------- Vòng lặp PSO ----------------------------------------
for it_pid = 1:max_iter_pid
    global best_fitness_pso_all
    r1_pid = rand(pop_size_pid, dim_pid);
    r2_pid = rand(pop_size_pid, dim_pid);

    vel_pid = w_inertia_pid*vel_pid ...
              + c1_pid*r1_pid.*(pbest_pid - pos_pid) ...
              + c2_pid*r2_pid.*(gbest_pid - pos_pid);
    pos_pid = pos_pid + vel_pid;

    pos_pid = max(pos_pid, lb_pid);
    pos_pid = min(pos_pid, ub_pid);

    for i = 1:pop_size_pid
        J_pid(i) = cost_fun_pid(pos_pid(i,:), xm0_pid, xs0_pid, ...
            N_pid, h_pid, alpha_pid, x_min_pid, x_max_pid, ...
            w_err_pid, u_max_pid, use_sat_pid);
    end

    improved_pid = J_pid < pbest_val_pid;
    pbest_pid(improved_pid,:) = pos_pid(improved_pid,:);
    pbest_val_pid(improved_pid) = J_pid(improved_pid);
    
    [cur_best_pid, idx2_pid] = min(J_pid);
    if cur_best_pid < gbest_val_pid
        gbest_val_pid = cur_best_pid;
        gbest_pid     = pos_pid(idx2_pid,:);
    end
    best_fitness_pso_all(it_pid) = 1/(gbest_val_pid^2 + 1);

    fprintf('Iter %3d/%3d | Best J = %.6g | Kp=%.4g Ki=%.4g Kd=%.4g\n', ...
        it_pid, max_iter_pid, gbest_val_pid, ...
        gbest_pid(1), gbest_pid(2), gbest_pid(3));
end

Kp_pid = gbest_pid(1); 
Ki_pid = gbest_pid(2); 
Kd_pid = gbest_pid(3);
fprintf('\nBest PID: Kp=%.6g, Ki=%.6g, Kd=%.6g | J=%.6g\n', ...
    Kp_pid, Ki_pid, Kd_pid, gbest_val_pid);

%% ---------------------- Mô phỏng lại với PID tối ưu -------------------------
[xm_pid, xs_pid, e_pid, u_hist_pid] = simulate_with_pid(gbest_pid, ...
    xm0_pid, xs0_pid, N_pid, h_pid, alpha_pid, x_min_pid, x_max_pid, ...
    w_err_pid, u_max_pid, use_sat_pid);


%% SMC_Method
% Ngưỡng phân hoạch mờ theo x1 (sector nonlinearity)
x_min_smc = -100;
x_max_smc =  100;

% Trạng thái ban đầu
xm_smc = zeros(4,N_smc);   % master: [x1;x2;x3;x4]
xs_smc = zeros(4,N_smc);   % slave
xm_smc(:,1) = [ 2;  2;  2;  2];
xs_smc(:,1) = [ 0;  0;  0;  0];

% Tham số hệ 4D
alpha_smc = 1.5;   

% Tham số điều khiển trượt
lambda_smc = [0.5; 0.5; 0.5; 0.5];    
k_smc      = [50; 50; 50; 50];    
delta_smc  = [0.01; 0.01; 0.01; 0.01];

sat_smc = @(s, d) max(min(s./d, 1), -1);   % hàm bão hoà liên tục

%% SMC Mô phỏng

% Vòng lặp mô phỏng
for k_step_smc = 1:N_smc-1

    % ===== MASTER: TS fuzzy (2 luật theo x1) =====
    x1m_smc = xm_smc(1,k_step_smc);
    w1m_smc = omega1_smc(x1m_smc, x_min_smc, x_max_smc);       
    w2m_smc = 1 - w1m_smc;                          

    % Luật 1 (x1 ~ x_min)
    f1m_smc = [ xm_smc(2,k_step_smc) - xm_smc(1,k_step_smc) + alpha_smc*xm_smc(4,k_step_smc) ;                         
                26*xm_smc(1,k_step_smc) - (x_min_smc)*xm_smc(3,k_step_smc) - xm_smc(2,k_step_smc) ;                    
                (x_min_smc)*xm_smc(2,k_step_smc) - 0.7*xm_smc(3,k_step_smc) ;                                   
               -xm_smc(1,k_step_smc) - xm_smc(4,k_step_smc) ];                                             

    % Luật 2 (x1 ~ x_max)
    f2m_smc = [ xm_smc(2,k_step_smc) - xm_smc(1,k_step_smc) + alpha_smc*xm_smc(4,k_step_smc) ;
                26*xm_smc(1,k_step_smc) - (x_max_smc)*xm_smc(3,k_step_smc) - xm_smc(2,k_step_smc) ;
                (x_max_smc)*xm_smc(2,k_step_smc) - 0.7*xm_smc(3,k_step_smc) ;
               -xm_smc(1,k_step_smc) - xm_smc(4,k_step_smc) ];

    fm_smc = w1m_smc*f1m_smc + w2m_smc*f2m_smc;                 
    xm_smc(:,k_step_smc+1) = xm_smc(:,k_step_smc) + h_smc*fm_smc;   

    % ===== SLAVE: TS fuzzy + điều khiển trượt với sat =====
    x1s_smc = xs_smc(1,k_step_smc);
    w1s_smc = omega1_smc(x1s_smc, x_min_smc, x_max_smc);
    w2s_smc = 1 - w1s_smc;

    % TS phần động lực
    f1s_smc = [ xs_smc(2,k_step_smc) - xs_smc(1,k_step_smc) + alpha_smc*xs_smc(4,k_step_smc) ;
                26*xs_smc(1,k_step_smc) - (x_min_smc)*xs_smc(3,k_step_smc) - xs_smc(2,k_step_smc) ;
                (x_min_smc)*xs_smc(2,k_step_smc) - 0.7*xs_smc(3,k_step_smc) ;
               -xs_smc(1,k_step_smc) - xs_smc(4,k_step_smc) ];

    f2s_smc = [ xs_smc(2,k_step_smc) - xs_smc(1,k_step_smc) + alpha_smc*xs_smc(4,k_step_smc) ;
                26*xs_smc(1,k_step_smc) - (x_max_smc)*xs_smc(3,k_step_smc) - xs_smc(2,k_step_smc) ;
                (x_max_smc)*xs_smc(2,k_step_smc) - 0.7*xs_smc(3,k_step_smc) ;
               -xs_smc(1,k_step_smc) - xs_smc(4,k_step_smc) ];

    fs_smc = w1s_smc*f1s_smc + w2s_smc*f2s_smc;

    % Sai số
    e_smc  = xm_smc(:,k_step_smc) - xs_smc(:,k_step_smc);
    if k_step_smc == 1
        e_prev_smc = e_smc;                          
    else
        e_prev_smc = xm_smc(:,k_step_smc-1) - xs_smc(:,k_step_smc-1);
    end

    % Bề mặt trượt
    s_smc = e_smc + lambda_smc .* e_prev_smc;

    % Luật điều khiển
    u_smc = k_smc .* sat_smc(s_smc, delta_smc) + s_smc;

    % Cập nhật slave
    xs_smc(:,k_step_smc+1) = xs_smc(:,k_step_smc) + h_smc*(fs_smc + u_smc);
end

%% BELC

for step=1:step_num
    %PLOT
    xm1_plot(step)=xm(1);
    xm2_plot(step)=xm(2);
    xm3_plot(step)=xm(3);
    xm4_plot(step)=xm(4);
    
    xs1_plot(step)=xs(1);
    xs2_plot(step)=xs(2);
    xs3_plot(step)=xs(3);
    xs4_plot(step)=xs(4);

    e_plot = xm - xs;
    sum_e=sum_e+sum(abs(e_plot));

    e1_plot(step)=e_plot(1);
    e2_plot(step)=e_plot(2);
    e3_plot(step)=e_plot(3);
    e4_plot(step)=e_plot(4);

    noise1_plot(step)=noise(1);
    noise2_plot(step)=noise(2);
    noise3_plot(step)=noise(3);
    noise4_plot(step)=noise(4);

    d_hat1_plot(step)=-d_hat(1);
    d_hat2_plot(step)=-d_hat(2);
    d_hat3_plot(step)=-d_hat(3);
    d_hat4_plot(step)=-d_hat(4);
    
    %%Lưu giá trị xm xs cho dob
    xm_old=xm;
    xs_old=xs;

    %MASTER SYSTEM
    xm_dot(1) = xm(2)-xm(1)+1.5*xm(4);
    xm_dot(2) = 26*xm(1)-xm(1)*xm(3)-xm(2);
    xm_dot(3) = xm(1)*xm(2)-0.7*xm(3);
    xm_dot(4) = -xm(1)-xm(4);

    xm = xm + xm_dot*h;

    %CONTROLLER   
    e = xm - xs;
    
    %%Khởi tạo quần thể ban đầu
    if step==3
        population = initial_pop(e, e_old, u, a, m_a, m_o, v_a, v_o, q_a, q_o, Phi_a, Phi_o, ...
            w_a, w_o, pop, n_ga, xm, xs);
    end
    
    %%Điều kiện tính toán ga
    e_old_ga=xm_old-xs_old;
    e_old=e;
    
    %%Bộ điều khiển
    [u, a, m_a, m_o, v_a, v_o, q_a, q_o, Phi_a, Phi_o, w_a, w_o, I_a, I_o, population] = controller(e, e_old, e_old_ga, u, a, m_a, m_o, ...
    v_a, v_o, q_a, q_o, Phi_a, Phi_o, w_a, w_o, I_a, I_o, population, pop, n_ga, xm, xs, step);

    % Nhiễu loạn ngẫu nhiên
    noise=10*sin(xm);

    %SLAVE SYSTEM 
    xs_dot(1) = xs(2)-xs(1)+1.5*xs(4);
    xs_dot(2) = 26*xs(1)-xs(1)*xs(3)-xs(2);
    xs_dot(3) = xs(1)*xs(2)-0.7*xs(3);   
    xs_dot(4) = -xs(1)-xs(4);

    xs=xs+(xs_dot+u)*h+noise;

    % %Kháng nhiễu
    d_hat = dob(xm, xs, d_hat, xm_old, xs_old);
    xs=xs+d_hat;

    disp(step);
end

%% ----------------- PID cố định (pidnpso) -----------------
% Hệ số PID chọn tay (ví dụ)
Kp_pidnpso = 15;
Ki_pidnpso = 1;
Kd_pidnpso = 0.5;

% Khởi tạo
xm_pidnpso = zeros(4,N_pid); 
xs_pidnpso = zeros(4,N_pid);
u_pidnpso  = zeros(4,N_pid);
e_pidnpso  = zeros(4,N_pid);

xm_pidnpso(:,1) = [2; 2; 2; 2];   % Master initial
xs_pidnpso(:,1) = [0; 0; 0; 0];   % Slave initial

int_e_pidnpso = zeros(4,1);   % tích phân sai số
e_prev_pidnpso = zeros(4,1);  % lưu sai số cũ

for k = 1:N_pid-1
    % ----- Master -----
    xm = xm_pidnpso(:,k);
    xm_dot = [ xm(2)-xm(1)+1.5*xm(4);
               26*xm(1)-xm(1)*xm(3)-xm(2);
               xm(1)*xm(2)-0.7*xm(3);
              -xm(1)-xm(4) ];
    xm_pidnpso(:,k+1) = xm + h_pid*xm_dot;

    % ----- Slave -----
    xs = xs_pidnpso(:,k);
    % Sai số
    e_pidnpso(:,k) = xm - xs;

    % PID (theo từng trạng thái)
    int_e_pidnpso = int_e_pidnpso + e_pidnpso(:,k)*h_pid;
    de = (e_pidnpso(:,k) - e_prev_pidnpso)/h_pid;

    u_pidnpso(:,k) = Kp_pidnpso*e_pidnpso(:,k) + Ki_pidnpso*int_e_pidnpso + Kd_pidnpso*de;

    % Dynamics + control
    xs_dot = [ xs(2)-xs(1)+1.5*xs(4);
               26*xs(1)-xs(1)*xs(3)-xs(2);
               xs(1)*xs(2)-0.7*xs(3);
              -xs(1)-xs(4) ];
    xs_pidnpso(:,k+1) = xs + h_pid*(xs_dot + u_pidnpso(:,k));

    % update sai số cũ
    e_prev_pidnpso = e_pidnpso(:,k);
end
e_pidnpso(:,N_pid) = xm_pidnpso(:,N_pid) - xs_pidnpso(:,N_pid);

%% === So sánh giá trị cuối và MSE (có PID+PSO & PIDnpso) ===

% 1) Gom sai số thành ma trận 4xN cho từng bộ điều khiển
e_all_belc    = [e1_plot; e2_plot; e3_plot; e4_plot];   % 4 x N_belc
e_all_smc     = xm_smc - xs_smc;                        % 4 x N_smc
e_all_pidpso  = e_pid;                                  % 4 x N_pid (PID+PSO)
e_all_pidnpso = e_pidnpso;                              % 4 x N_pid (PID tay cố định)

% 2) Sai số cuối cùng (vector 4x1)
e_belc_final    = e_all_belc(:,end);
e_smc_final     = e_all_smc(:,end);
e_pidpso_final  = e_all_pidpso(:,end);
e_pidnpso_final = e_all_pidnpso(:,end);

% 3) Hàm hỗ trợ tính chỉ số theo thời gian (ITAE/ISE/IAE, v.v.)
compute_metrics_with_time = @(e_all, tvec,h) local_compute_metrics_with_time(e_all, tvec, h);

% 4) Tính chỉ số cho từng bộ
metrics_belc    = local_compute_metrics_with_time(e_all_belc,    t(:),     h);
metrics_smc     = local_compute_metrics_with_time(e_all_smc,     time_smc(:), h_smc);
metrics_pidpso  = local_compute_metrics_with_time(e_all_pidpso,  t_pid(:), h_pid);
metrics_pidnpso = local_compute_metrics_with_time(e_all_pidnpso, t_pid(:), h_pid);

% 5) In kết quả ra màn hình
disp('=== Kết quả đánh giá BELC ===');    disp(metrics_belc);
disp(['Sai số cuối BELC: ',    mat2str(e_belc_final,4)]);

disp('=== Kết quả đánh giá SMC ===');     disp(metrics_smc);
disp(['Sai số cuối SMC : ',     mat2str(e_smc_final,4)]);

disp('=== Kết quả đánh giá PID+PSO ==='); disp(metrics_pidpso);
disp(['Sai số cuối PID+PSO : ', mat2str(e_pidpso_final,4)]);

disp('=== Kết quả đánh giá PIDnpso ==='); disp(metrics_pidnpso);
disp(['Sai số cuối PIDnpso : ', mat2str(e_pidnpso_final,4)]);

%% === Đồ thị giám sát GA (giữ nguyên) ===
global best_fitness_ga_all
if exist('best_fitness_ga_all','var') && ~isempty(best_fitness_ga_all)
    figure;
    plot(1:numel(best_fitness_ga_all), best_fitness_ga_all, 'LineWidth', 2);
    xlabel('GA iteration', 'FontSize', 20, 'FontWeight', 'bold');
    ylabel('Best fitness', 'FontSize', 20, 'FontWeight', 'bold');
    title('GA Best Fitness over Iterations', 'FontSize', 24, 'FontWeight', 'bold');
    grid on; set(gca, 'FontSize', 18);
    
    figure;
    glob_best_ga = cummax(best_fitness_ga_all);
    plot(1:numel(glob_best_ga), glob_best_ga, 'r', 'LineWidth', 2);
    xlabel('GA iteration', 'FontSize', 20, 'FontWeight', 'bold');
    ylabel('Global best fitness', 'FontSize', 20, 'FontWeight', 'bold');
    title('GA Global Best Fitness (cumulative max)', 'FontSize', 24, 'FontWeight', 'bold');
    grid on; set(gca, 'FontSize', 18);

    % figure;
    % histogram(best_fitness_ga_all, 60);
    % xlabel('Fitness', 'FontSize', 20, 'FontWeight', 'bold');
    % ylabel('Count', 'FontSize', 20, 'FontWeight', 'bold');
    % title('Histogram of GA Best Fitness', 'FontSize', 24, 'FontWeight', 'bold');
    % grid on; set(gca, 'FontSize', 18);
end

%% === Đồ thị giám sát PSO (tương tự GA) ===
global best_fitness_pso_all
if exist('best_fitness_pso_all','var') && ~isempty(best_fitness_pso_all)
    figure;
    plot(1:numel(best_fitness_pso_all), best_fitness_pso_all, 'LineWidth', 2);
    xlabel('PSO iteration', 'FontSize', 20, 'FontWeight', 'bold');
    ylabel('Best fitness', 'FontSize', 20, 'FontWeight', 'bold');
    title('PSO Best Fitness over Iterations', 'FontSize', 24, 'FontWeight', 'bold');
    grid on; set(gca, 'FontSize', 18);

    % figure;
    % glob_best_pso = cummax(best_fitness_pso_all);
    % plot(1:numel(glob_best_pso), glob_best_pso, 'r', 'LineWidth', 2);
    % xlabel('PSO iteration', 'FontSize', 20, 'FontWeight', 'bold');
    % ylabel('Global best fitness', 'FontSize', 20, 'FontWeight', 'bold');
    % title('PSO Global Best Fitness (cumulative max)', 'FontSize', 24, 'FontWeight', 'bold');
    % grid on; set(gca, 'FontSize', 18);

    % figure;
    % histogram(best_fitness_pso_all, 40);
    % xlabel('Fitness', 'FontSize', 20, 'FontWeight', 'bold');
    % ylabel('Count', 'FontSize', 20, 'FontWeight', 'bold');
    % title('Histogram of PSO Best Fitness', 'FontSize', 24, 'FontWeight', 'bold');
    % grid on; set(gca, 'FontSize', 18);
end

%% === So sánh lỗi: BELC vs SMC vs PID+PSO vs PIDnpso ===
titles = {'Tracking error on x axis', ...
          'Tracking error on y axis', ...
          'Tracking error on z axis', ...
          'Tracking error on w axis'};

vars_belc    = {e_all_belc(1,:),    e_all_belc(2,:),    e_all_belc(3,:),    e_all_belc(4,:)};
vars_smc     = num2cell(e_all_smc,2);
vars_pidpso  = num2cell(e_all_pidpso,2);
vars_pidnpso = num2cell(e_all_pidnpso,2);

figure('Name','Tracking errors comparison');
for i = 1:4
    subplot(4,1,i);
    plot(time,     vars_belc{i},    'r-',  'LineWidth', 2); hold on;   % BELC
    plot(time_smc, vars_smc{i},     'b--', 'LineWidth', 2);            % SMC
    plot(t_pid,    vars_pidpso{i},  'g-.', 'LineWidth', 2);            % PID+PSO
    plot(t_pid,    vars_pidnpso{i}, 'm:',  'LineWidth', 2);            % PIDnpso
    grid on;

    ylabel(['e_',num2str(i)], 'FontSize', 14, 'FontWeight', 'bold');
    title(titles{i}, 'FontSize', 16, 'FontWeight', 'bold');

    if i==4
        xlabel('Time (s)', 'FontSize', 14, 'FontWeight', 'bold');
    end

    set(gca, 'FontSize', 12);
end

%% ================= HÀM CỤC BỘ TÍNH SỐ LIỆU =================
function metrics = local_compute_metrics_with_time(e_all, tvec, h)
    % e_all: (n_state x N) lỗi
    % tvec : (N x 1) vector thời gian
    % h    : bước thời gian
    
    if size(e_all,2) ~= numel(tvec)
        error('Kích thước thời gian không khớp: e_all (N=%d) vs tvec (N=%d).',...
               size(e_all,2), numel(tvec));
    end
    
    % Sai số cuối cùng
    ess_vec = e_all(:,end);
    
    % Tính toán các chỉ số
    metrics = struct( ...
        'MAE',        mean(abs(e_all), 'all'), ...
        'MSE',        mean(e_all.^2, 'all'), ...
        'RMSE',       sqrt(mean(e_all.^2, 'all')), ...
        'IAE',        sum(abs(e_all), 'all')*h, ...
        'ISE',        sum(e_all.^2, 'all')*h, ...
        'ITAE',       sum(tvec(:) .* sum(abs(e_all),1)')*h, ...
        'ESS_euclid', norm(ess_vec,2) ...   % sqrt(e1^2+e2^2+e3^2+e4^2)
    );
end


%% Function $$$$
%%Hàm DOB
function d_hat = dob(xm, xs, d_hat, xm_old, xs_old)
    Kd=1e-5;
    Kd_hat=1e-5;
    d_hat=xm-xs + Kd_hat*d_hat + Kd*(xm_old-xs_old);
end

%%Hàm khởi tạo quần thể ban đầu có chọn lọc
function population = initial_pop(e, e_old, u, a, m_a, m_o, v_a, v_o, q_a, q_o, Phi_a, Phi_o, w_a, w_o, m, n, xm, xs)
    xs_dot(1) = xs(2)-xs(1)+1.5*xs(4);
    xs_dot(2) = 26*xs(1)-xs(1)*xs(3)-xs(2);
    xs_dot(3) = xs(1)*xs(2)-0.7*xs(3);   
    xs_dot(4) = -xs(1)-xs(4);

    population=zeros(m,n);

    f=cell(1,4);
    for i=1:4
        f{i} = [1; e(i); sin(e(i)); cos(e(i))];
    end

    for i=1:m
        pop = create_population(m, n);
        [pop, ~] = sort_fitness_population(e, e_old, u, a, m_a, m_o, v_a, v_o, q_a, q_o, Phi_a, Phi_o, w_a, w_o, f, pop, m, xm, xs, xs_dot);
        population(i,:) = pop(m,:);
    end
    
    [population, ~] = sort_fitness_population(e, e_old, u, a, m_a, m_o, v_a, v_o, q_a, q_o, Phi_a, Phi_o, w_a, w_o, f, population, m, xm, xs, xs_dot);
end

%%Bộ điều khiển
function [u, a, m_a, m_o, v_a, v_o, q_a, q_o, Phi_a, Phi_o, w_a, w_o, I_a, I_o, population] = controller(e, e_old, e_old_ga, u, a, m_a, m_o, ...
    v_a, v_o, q_a, q_o, Phi_a, Phi_o, w_a, w_o, I_a, I_o, population, pop, n_ga, xm, xs, step)
    
    xs_dot(1) = xs(2)-xs(1)+1.5*xs(4);
    xs_dot(2) = 26*xs(1)-xs(1)*xs(3)-xs(2);
    xs_dot(3) = xs(1)*xs(2)-0.7*xs(3);   
    xs_dot(4) = -xs(1)-xs(4);

    for i=1:4
        [m_a{i}, m_o{i}, v_a{i}, v_o{i}, Phi_a{i}, Phi_o{i}, w_a{i}, w_o{i}, q_a{i}, q_o{i}, I_a{i}, I_o{i}] = SO(e(i), m_a{i}, m_o{i}, v_a{i}, ...
            v_o{i}, Phi_a{i}, Phi_o{i}, w_a{i}, w_o{i}, q_a{i}, q_o{i}, I_a{i}, I_o{i});
    end

    if step>5     
        e_check=zeros(1,4);
        
        for i=1:4
            e_check(i) = check(e(i), e_old(i), u(i), a(i), w_a{i}, w_o{i}, m_a{i}, m_o{i}, Phi_a{i}, Phi_o{i}, v_a{i}, v_o{i}, ...
                q_a{i}, q_o{i}, xm(i), xs(i), xs_dot(i), population, pop);
        end
        
        if sum(abs(e_check)) > sum(abs(e_old_ga))
            population = GA(e, e_old, e_check, e_old_ga, u, a, m_a, m_o, v_a, v_o, q_a, q_o, Phi_a, Phi_o, w_a, w_o, population, pop, n_ga, xm, xs, xs_dot);
        end
    end

    for i=1:4
        [u(i), a(i), w_a{i}, w_o{i}, m_a{i}, m_o{i}, Phi_a{i}, Phi_o{i}, v_a{i}, v_o{i}, q_a{i}, q_o{i}] = BELC(e(i), ...
         e_old(i), u(i), a(i), w_a{i}, w_o{i}, m_a{i}, m_o{i}, Phi_a{i}, Phi_o{i}, v_a{i}, v_o{i}, q_a{i}, q_o{i}, population, pop);
    end
end

%%Bộ điều khiển ảo kiểm tra sai số tiếp theo
function e_check = check(e, e_old, u, a, w_a, w_o, m_a, m_o, Phi_a, Phi_o, v_a, v_o, q_a, q_o, xm, xs, xs_dot, population, pop)
    eta_m_a=population(pop, 1);
    eta_m_o=population(pop, 2);
    eta_v_a=population(pop, 3);
    eta_v_o=population(pop, 4);
    eta_q_a=population(pop, 5);
    eta_q_o=population(pop, 6);
    eq=100;
    h=0.001;

    s=e;
    
    %Function
    f = [1; e; sin(e); cos(e)];

    %%%%% Update Parameters
    % Update mean
    delta_m_a = eta_m_a  * s * w_a' .* Phi_a .* 2.*(e_old-m_a)./v_a.^2;
    delta_m_o = -eta_m_o * s * w_o' .* Phi_o .* 2.*(e_old-m_o)./v_o.^2;

    % Update variance
    delta_v_a = eta_v_a * s * w_a' .* Phi_a .* 2.*(e_old-m_a).^2./v_a.^3;
    delta_v_o = -eta_v_o * s * w_o' .* Phi_o .* 2.*(e_old-m_o).^2./v_o.^3;

    % Update weight
    dq = eq*s+u;
    delta_q_a = eta_q_a*max(0,dq-a)*(f*Phi_a)';
    delta_q_o = eta_q_o*(u-dq)*(f*Phi_o)';

    m_a_check=m_a+delta_m_a;
    m_o_check=m_o+delta_m_o;
    v_a_check=v_a+delta_v_a;
    v_o_check=v_o+delta_v_o;
    q_a_check=q_a+delta_q_a;
    q_o_check=q_o+delta_q_o;

    %Weight
    w_a_check = q_a_check*f;
    w_o_check = q_o_check*f;

    %Gauss function
    Phi_a_check = exp(-(e-m_a_check).^2./v_a_check.^2);
    Phi_o_check = exp(-(e-m_o_check).^2./v_o_check.^2);

    %Layer 2
    a_check = Phi_a_check*w_a_check;
    o_check = Phi_o_check*w_o_check;

    %Control law
    u_check = a_check - o_check; 

    xs_check = xs + (xs_dot+u_check)*h;

    e_check=xm-xs_check;
end

%Thuật toán di truyền
function population = GA(e, e_old, e_check, e_old_ga, u, a, m_a, m_o, v_a, v_o, q_a, q_o, Phi_a, Phi_o, w_a, w_o, population, pop, ~, xm, xs, xs_dot) 
    global best_fitness_ga_all
    %Function  
    f=cell(1,4);
    for i=1:4
        f{i} = [1; e(i); sin(e(i)); cos(e(i))];
    end
    
    e_threshhold=0.0025;
    ga_time=100;
    time_ga=0;
   
    if e_threshhold < sum(abs(e_check))
        disp(['GA đang chạy']);
        while(time_ga<ga_time)
            time_ga=time_ga+1;
            population = create_new_population(population, pop);
            [population, max_fitness] = sort_fitness_population(e, e_old, u, a, m_a, m_o, v_a, v_o, q_a, q_o, Phi_a, Phi_o, ...
            w_a, w_o, f, population, pop, xm, xs, xs_dot);
            best_fitness_ga_all(end+1) = max_fitness;

            if max_fitness>1/(sum(abs(e_old_ga))+1)
                break;
            end
        end
    end
end

%Tính độ thích nghi mỗi cá thể
function [population, max_fitness] = sort_fitness_population(e, e_old, u, a, m_a, m_o, v_a, v_o, q_a, q_o, Phi_a, Phi_o, ...
    w_a, w_o, f, population, pop, xm, xs, xs_dot)
    fitness_value=zeros(pop,1);
    u_ga=zeros(1,4);
    h=0.001;
    s=e;

    for gen=1:pop
        eta_m_a=population(gen, 1);
        eta_m_o=population(gen, 2);
        eta_v_a=population(gen, 3);
        eta_v_o=population(gen, 4);
        eta_q_a=population(gen, 5);
        eta_q_o=population(gen, 6);
        eq=100;
        for i=1:4 
            %%%%% Update Parameters
            % Update mean
            delta_m_a = eta_m_a * s(i) * w_a{i}' .* Phi_a{i} .* 2.*(e_old(i)-m_a{i})./v_a{i}.^2;
            delta_m_o = -eta_m_o * s(i) * w_o{i}' .* Phi_o{i}.* 2.*(e_old(i)-m_o{i})./v_o{i}.^2;
    
            % Update variance
            delta_v_a = eta_v_a * s(i) * w_a{i}' .* Phi_a{i} .* 2.*(e_old(i)-m_a{i}).^2./v_a{i}.^3;
            delta_v_o = -eta_v_o * s(i) * w_o{i}' .* Phi_o{i}.* 2.*(e_old(i)-m_o{i}).^2./v_o{i}.^3;
    
            % Update weight
            dq = eq*s(i)+u(i);
            delta_q_a = eta_q_a*max(0,dq-a(i))*(f{i}*Phi_a{i})';
            delta_q_o = eta_q_o*(u(i)-dq)*(f{i}*Phi_o{i})';
    
            m_a_ga=m_a{i}+delta_m_a;
            m_o_ga=m_o{i}+delta_m_o;
            v_a_ga=v_a{i}+delta_v_a;
            v_o_ga=v_o{i}+delta_v_o;
            q_a_ga=q_a{i}+delta_q_a;
            q_o_ga=q_o{i}+delta_q_o;
    
            %Weight
            w_a_ga = q_a_ga*f{i};
            w_o_ga = q_o_ga*f{i};
    
            %Gauss function
            Phi_a_ga = exp(-(e(i)-m_a_ga).^2./v_a_ga.^2);
            Phi_o_ga = exp(-(e(i)-m_o_ga).^2./v_o_ga.^2);
    
            %Layer 2
            a_ga = Phi_a_ga*w_a_ga;
            o_ga = Phi_o_ga*w_o_ga;
    
            %Control law
            u_ga(i) = a_ga - o_ga;   
        end
        
        %SLAVE SYSTEM 
        xs_ga = xs + (xs_dot+u_ga)*h;

        e_ga=xm-xs_ga;

        fitness_value(gen) = 1/(sum(abs(e_ga))+1);
    end
    max_fitness=max(fitness_value);
    fitness_value=fitness_value*power(10,5);
    population = sort_function(population, fitness_value);
end

%Bộ điều khiển mô phỏng học tập cảm xúc não
function [u, a, w_a, w_o, m_a, m_o, Phi_a, Phi_o, v_a, v_o, q_a, q_o] = BELC(e, e_old, u, a, w_a, w_o, m_a, m_o, Phi_a, Phi_o, v_a, v_o, ...
    q_a, q_o, population, pop)
    eta_m_a=population(pop, 1);
    eta_m_o=population(pop, 2);
    eta_v_a=population(pop, 3);
    eta_v_o=population(pop, 4);
    eta_q_a=population(pop, 5);
    eta_q_o=population(pop, 6);
    eq=100;

    %Function
    f = [1; e; sin(e); cos(e)]; 

    s=e;

    %%%%% Update Parameters
    % Update mean
    delta_m_a = eta_m_a  * s * w_a' .* Phi_a .* 2.*(e_old-m_a)./v_a.^2;
    delta_m_o = -eta_m_o  * s * w_o' .* Phi_o .* 2.*(e_old-m_o)./v_o.^2;

    % Update variance
    delta_v_a = eta_v_a * s * w_a' .* Phi_a .* 2.*(e_old-m_a).^2./v_a.^3;
    delta_v_o = -eta_v_o * s * w_o' .* Phi_o .* 2.*(e_old-m_o).^2./v_o.^3;

    % Update weight
    dq = eq*s+u;
    delta_q_a = eta_q_a*max(0,dq-a)*(f*Phi_a)';
    delta_q_o = eta_q_o*(u-dq)*(f*Phi_o)';
    
    m_a=m_a+delta_m_a;
    m_o=m_o+delta_m_o;
    v_a=v_a+delta_v_a;
    v_o=v_o+delta_v_o;
    q_a=q_a+delta_q_a;
    q_o=q_o+delta_q_o;
   
    %Weight
    w_a = q_a*f;
    w_o = q_o*f;

    %Gauss function
    Phi_a = exp(-(e-m_a).^2./v_a.^2);
    Phi_o = exp(-(e-m_o).^2./v_o.^2);

    %Layer 2
    a = Phi_a*w_a;
    o = Phi_o*w_o;
    
    %Control law
    u = a-o; 
end

%Cơ chế tự thay đổi số lượng nơ-ron
function [m_a, m_o, v_a, v_o, Phi_a, Phi_o, w_a, w_o, q_a, q_o, I_a, I_o] = SO(e, m_a, m_o, v_a, v_o, Phi_a, Phi_o, w_a, w_o, q_a, q_o, I_a, I_o)
    % % Self Organizing
    T_i = 0.7;
    T_d1 = 0.7;
    T_d2 = 0.1;
    Tau_1 = 100;
    Tau_2 = 10; 
    vectorq = zeros(1, 4);
    % Neural increasing
    % a
    max_Phi_a = max(Phi_a);
    if (max_Phi_a<T_i)
        m_a = [m_a e];
        v_a = [v_a sum(v_a)/numel(v_a)];
        Phi_a = [Phi_a 1];
        w_a = [w_a; 1];
        q_a = [q_a; vectorq];
        I_a = [I_a; 1];
    end

    % o
    max_Phi_o = max(Phi_o);
    if (max_Phi_o<T_i)
        m_o = [m_o e];
        v_o = [v_o sum(v_o)/numel(v_o)];
        Phi_o = [Phi_o 1];
        w_o = [w_o; 1];
        q_o = [q_o; vectorq];
        I_o = [I_o; 1];
    end

    % Neural decreasing
    % a
    i = 1;
    while i <= numel(Phi_a)
        if Phi_a(i) < T_d1
            I_a(i) = I_a(i)*exp(-(1-Phi_a(i))/Tau_1);
        else
            I_a(i) = I_a(i)*(2-exp(-Phi_a(i)*(1-I_a(i))/Tau_2));
        end
        if I_a(i) < T_d2
            m_a = [m_a(1:(i-1)) m_a((i+1):numel(I_a))];
            v_a = [v_a(1:(i-1)) v_a((i+1):numel(I_a))];
            Phi_a = [Phi_a(1:(i-1)) Phi_a((i+1):numel(I_a))];
            w_a = [w_a(1:(i-1)); w_a((i+1):numel(I_a))];
            q_a = [q_a(1:(i-1),:); q_a((i+1):numel(I_a),:)];
            I_a = [I_a(1:(i-1)); I_a((i+1):numel(I_a))];
            i = i-1;
        end
        i = i+1;
    end

    % o
    i = 1;
    while i <= numel(Phi_o)
        if Phi_o(i) < T_d1
            I_o(i) = I_o(i)*exp(-(1-Phi_o(i))/Tau_1);
        else
            I_o(i) = I_o(i)*(2-exp(-Phi_o(i)*(1-I_o(i))/Tau_2));
        end
        if I_o(i) < T_d2
            m_o = [m_o(1:(i-1)) m_o((i+1):numel(I_o))];
            v_o = [v_o(1:(i-1)) v_o((i+1):numel(I_o))];
            Phi_o = [Phi_o(1:(i-1)) Phi_o((i+1):numel(I_o))];
            w_o = [w_o(1:(i-1)); w_o((i+1):numel(I_o))];
            q_o = [q_o(1:(i-1),:); q_o((i+1):numel(I_o),:)];
            I_o = [I_o(1:(i-1)); I_o((i+1):numel(I_o))];
            i = i-1;
        end
        i = i+1; 
    end
end

%%%GA
function result = create_gen(max_val, min_val) %khởi tạo gen
    result=10^(min_val + (max_val - min_val) * rand());   
end

function sorted_population = sort_function(population, fitness_value)   %sắp xếp quần thể theo chiều tăng dần độ thích nghi từng cá thể
    population_with_fitness = [fitness_value population];
    sorted_population_with_fitness = sortrows(population_with_fitness, 1);
    sorted_population = sorted_population_with_fitness(:, 2:end);
end

function individual_s = selection(sorted_population, m)   %lựa chọn cá thể
    index1=randi([1, m]);
    while true
        index2=randi([1, m]);
        if index1~=index2
            break
        end
    end

    individual_s = sorted_population(index1, :);

    if index2 > index1
        individual_s = sorted_population(index2, :);
    end
end

function [individual1_new, individual2_new] = crossover(individual1, individual2)   %lai ghép
    crossover_rate=0.9;
    individual1_new=individual1;
    individual2_new=individual2;
    for i=1:6
        if rand < crossover_rate
            individual1_new(i)=individual2(i);
            individual2_new(i)=individual1(i);
        else
            individual1_new(i)=individual1(i);
            individual2_new(i)=individual2(i);
        end
    end
end

function result = create_population(m, n)  %khởi tạo quần thể ngẫu nhiên
    result = zeros(m,n);
    for i=1:m
        for j=1:n
            result(i,j)=create_gen(1, -7); 
        end 
    end
end

function individual_m = mutate(individual)     %đột biến
    individual_m=individual;
    mutation_rate=0.1;

    for i=1:6
        if rand < mutation_rate
            individual_m(i) = create_gen(1, -7);
        else
            individual_m(i) = individual(i);
        end
    end
end

function new_population= create_new_population(old_population, m)   %tiến hoá, khởi tạo quần thể mới
    etilism = 2;
    new_population=old_population;
    for i=1:2:m-etilism
        individual_s1 = selection(old_population, m);  
        individual_s2 = selection(old_population, m);

        [individual_c1, individual_c2] = crossover(individual_s1, individual_s2);

        individual_m1 = mutate(individual_c1);
        individual_m2 = mutate(individual_c2);

        new_population(i,:)=individual_m1;
        new_population(i+1,:)=individual_m2;
    end 
end

%% ====== HÀM TRỌNG SỐ MỜ (2 luật) ======
function w1_smc = omega1_smc(x_smc, x_min_smc, x_max_smc)
    if x_smc < x_min_smc, x_smc = x_min_smc; elseif x_smc > x_max_smc, x_smc = x_max_smc; end
    w1_smc = (x_max_smc - x_smc)/(x_max_smc - x_min_smc);   
end

%% ======================= HÀM PHỤ =======================

function J_pid = cost_fun_pid(K_pid, xm0_pid, xs0_pid, N_pid, h_pid, ...
    alpha_pid, x_min_pid, x_max_pid, w_err_pid, u_max_pid, use_sat_pid)

    [xm_pid, xs_pid, e_pid, ~] = simulate_with_pid(K_pid, xm0_pid, xs0_pid, ...
        N_pid, h_pid, alpha_pid, x_min_pid, x_max_pid, w_err_pid, ...
        u_max_pid, use_sat_pid);

    t_pid = (0:N_pid-1)*h_pid;
    abs_err_pid = sum(abs(e_pid).*w_err_pid, 1);
    J_pid = sum(t_pid .* abs_err_pid) * h_pid;

    if ~isfinite(J_pid) || isnan(J_pid)
        J_pid = 1e12;
    end
end

function [xm_pid, xs_pid, e_pid, u_hist_pid] = simulate_with_pid( ...
    K_pid, xm0_pid, xs0_pid, N_pid, h_pid, alpha_pid, ...
    x_min_pid, x_max_pid, w_err_pid, u_max_pid, use_sat_pid)

    Kp_pid = K_pid(1); 
    Ki_pid = K_pid(2); 
    Kd_pid = K_pid(3);

    xm_pid = zeros(4,N_pid); 
    xs_pid = zeros(4,N_pid);
    xm_pid(:,1) = xm0_pid; 
    xs_pid(:,1) = xs0_pid;

    e_prev_pid   = xm_pid(:,1) - xs_pid(:,1);
    I_state_pid  = zeros(4,1);
    u_hist_pid   = zeros(4,N_pid);

    for k_pid = 1:N_pid-1
        % Master
        x1m_pid = xm_pid(1,k_pid);
        w1m_pid = omega1_pid(x1m_pid, x_min_pid, x_max_pid);
        w2m_pid = 1 - w1m_pid;

        f1m_pid = [ xm_pid(2,k_pid) - xm_pid(1,k_pid) + alpha_pid*xm_pid(4,k_pid) ;
                    26*xm_pid(1,k_pid) - (x_min_pid)*xm_pid(3,k_pid) - xm_pid(2,k_pid) ;
                    (x_min_pid)*xm_pid(2,k_pid) - 0.7*xm_pid(3,k_pid) ;
                   -xm_pid(1,k_pid) - xm_pid(4,k_pid) ];
        f2m_pid = [ xm_pid(2,k_pid) - xm_pid(1,k_pid) + alpha_pid*xm_pid(4,k_pid) ;
                    26*xm_pid(1,k_pid) - (x_max_pid)*xm_pid(3,k_pid) - xm_pid(2,k_pid) ;
                    (x_max_pid)*xm_pid(2,k_pid) - 0.7*xm_pid(3,k_pid) ;
                   -xm_pid(1,k_pid) - xm_pid(4,k_pid) ];

        fm_pid = w1m_pid*f1m_pid + w2m_pid*f2m_pid;
        xm_pid(:,k_pid+1) = xm_pid(:,k_pid) + h_pid*fm_pid;

        % Slave
        x1s_pid = xs_pid(1,k_pid);
        w1s_pid = omega1_pid(x1s_pid, x_min_pid, x_max_pid);
        w2s_pid = 1 - w1s_pid;

        f1s_pid = [ xs_pid(2,k_pid) - xs_pid(1,k_pid) + alpha_pid*xs_pid(4,k_pid) ;
                    26*xs_pid(1,k_pid) - (x_min_pid)*xs_pid(3,k_pid) - xs_pid(2,k_pid) ;
                    (x_min_pid)*xs_pid(2,k_pid) - 0.7*xs_pid(3,k_pid) ;
                   -xs_pid(1,k_pid) - xs_pid(4,k_pid) ];
        f2s_pid = [ xs_pid(2,k_pid) - xs_pid(1,k_pid) + alpha_pid*xs_pid(4,k_pid) ;
                    26*xs_pid(1,k_pid) - (x_max_pid)*xs_pid(3,k_pid) - xs_pid(2,k_pid) ;
                    (x_max_pid)*xs_pid(2,k_pid) - 0.7*xs_pid(3,k_pid) ;
                   -xs_pid(1,k_pid) - xs_pid(4,k_pid) ];

        fs_pid = w1s_pid*f1s_pid + w2s_pid*f2s_pid;

        % PID
        e_now_pid = xm_pid(:,k_pid) - xs_pid(:,k_pid);
        I_state_pid = I_state_pid + e_now_pid*h_pid;
        de_pid = (e_now_pid - e_prev_pid)/h_pid;

        u_pid = Kp_pid*e_now_pid + Ki_pid*I_state_pid + Kd_pid*de_pid;
        if use_sat_pid
            u_pid = min(max(u_pid, -u_max_pid), u_max_pid);
        end
        u_hist_pid(:,k_pid) = u_pid;

        xs_pid(:,k_pid+1) = xs_pid(:,k_pid) + h_pid*(fs_pid + u_pid);

        e_prev_pid = e_now_pid;
    end

    e_pid = xm_pid - xs_pid;
end

function w1_pid = omega1_pid(x1_pid, xmin_pid, xmax_pid)
    if xmax_pid == xmin_pid
        w1_pid = 0.5;
        return;
    end
    w1_pid = (xmax_pid - x1_pid) / (xmax_pid - xmin_pid);
    if w1_pid < 0, w1_pid = 0; end
    if w1_pid > 1, w1_pid = 1; end
end