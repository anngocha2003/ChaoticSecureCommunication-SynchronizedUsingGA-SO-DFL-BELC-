function result = estimate_Keff_hyper4d()
%==========================================================
% 0) CẤU HÌNH — SỬA CHO PHÙ HỢP VỚI THỰC NGHIỆM CỦA BẠN
%==========================================================

% 0.1 Bộ tham số/IC cố định (nếu bạn muốn "gắn cứng" vài biến)
fixed.A = 1; 
fixed.B = 1; 
fixed.C = 1.5; 
fixed.D = 26.36; 
fixed.E = 0.5;
fixed.x0 = 1.82; 
fixed.y0 = -12.482; 
fixed.z0 = 34.4; 
fixed.w0 = -0.11;

% 0.2 Khoảng khảo sát cho các biến bạn MUỐN MONTE-CARLO
%    (chỉ những trường có mặt trong 'ranges' mới được lấy ngẫu nhiên)
ranges = struct();
ranges.D  = [20 30];
ranges.E  = [0.5 1.0];
ranges.x0 = [-7 9];
ranges.y0 = [-20 23];
ranges.z0 = [0 43];
ranges.w0 = [-3 4];

% 0.3 Độ phân giải lưới hiệu dụng (attacker cần phân biệt đến mức nào)
%     -> dùng để tính K_grid = sum log2((b-a)/Δ)
%     (điền theo hệ/độ nhạy đồng bộ của bạn)
delta = struct();
delta.D  = 1e-3;
delta.E  = 1e-4;
delta.x0 = 1e-4;
delta.y0 = 1e-4;
delta.z0 = 1e-4;
delta.w0 = 1e-4;

% 0.4 Đối xứng/đẳng cấu (nếu có). Nếu không biết: =1
sym_equiv_classes = 1;

% 0.5 Cho phép dịch thời gian tối đa (mẫu) khi so khớp (nếu không có seq)
max_time_shift = 1;   % có seq nghiêm ngặt => để 1

% 0.6 Tham số mô phỏng / sinh keystream
sim = struct();
sim.h = 1e-3;           % bước Euler
sim.burnin = 2.0;       % giây burn-in
sim.quant = 256;        % lượng tử ra byte
sim.mix_alpha = 2^14;   % scale trước khi frac (có thể tinh chỉnh)
sim.decim = 1;          % decimation (>=1)
sim.use_hyperchaos_only = true;  % lọc chỉ giữ cấu hình có ≥2 LE dương

% 0.7 Monte-Carlo
B = 1e5;                % số bộ tham số thử (tăng nếu muốn CI hẹp)
rng(123);               % seed

% 0.8 Metric khớp (chọn 1)
match_metric = 'RMSE';  % 'RMSE' | 'CORR'
tau = 0.5;              % ngưỡng RMSE (byte)
corr_min = 0.98;        % nếu dùng CORR

% 0.9 Tải keystream tham chiếu (N×1 uint8)
ref_path = 'ks_ref.mat';
steps_burn = round(sim.burnin/sim.h);   % dùng luôn cho ref và MC
try
    S = load(ref_path,'ks_ref');            % thử load từ file
    ks_ref = S.ks_ref(:);
    N = numel(ks_ref);
catch
    warning('ks_ref.mat not found or invalid. Generating reference from FIXED parameters...');
    % sinh keystream tham chiếu từ bộ tham số cố định 'fixed'
    ks_ref = simulate_keystream_hyper4d(fixed, 10000, steps_burn, sim);  % bạn có thể đổi 10000
    ks_ref = uint8(ks_ref(:));
    N = numel(ks_ref);
    save(ref_path,'ks_ref');                % lưu lại để các lần sau load được
end
%==========================================================
% 1) TÍNH K_grid TỪ DẢI VÀ Δ
%==========================================================
K_grid = 0;
fn = fieldnames(ranges);
for i = 1:numel(fn)
    key = fn{i};
    a = ranges.(key)(1); b = ranges.(key)(2);
    if isfield(delta,key)
        d = delta.(key);
    else
        error('Thiếu delta cho %s', key);
    end
    Ki = log2( (b - a) / d );
    if ~isfinite(Ki) || Ki < 0, Ki = 0; end
    K_grid = K_grid + Ki;
end

%==========================================================
% 2) TRỪ ĐỐI XỨNG + DỊCH THỜI GIAN
%==========================================================
Delta_sym   = log2(sym_equiv_classes);
Delta_shift = log2(max(1, max_time_shift));
K_after     = K_grid - Delta_sym - Delta_shift;

%==========================================================
% 3) MONTE-CARLO ƯỚC LƯỢNG q (BÓNG "ĐỦ GIỐNG")
%==========================================================
succ = 0;

% chuẩn bị shifts
if max_time_shift > 1
    shifts = 0:(max_time_shift-1);
else
    shifts = 0;
end

% số bước burn-in + dữ liệu
steps_burn = round(sim.burnin/sim.h);

% vòng lặp
for b = 1:B
    % 3.1 Lấy 1 bộ tham số/IC từ fixed + ranges
    theta = fixed; % copy
    for i = 1:numel(fn)
        key = fn{i};
        a = ranges.(key)(1); bnd = ranges.(key)(2);
        d = delta.(key);
        cells = max(1, floor((bnd - a)/d));   % số ô lưới
        idx = randi(cells+1);
        theta.(key) = a + (idx-1)*d;          % biên trái ô (có thể thêm jitter nhỏ)
    end

    % 3.2 (Tuỳ chọn) kiểm tra hyperchaos bằng Lyapunov
    if sim.use_hyperchaos_only
        [LEs, cnt_pos] = lyap4d_lu(theta.A,theta.B,theta.C,theta.D,theta.E, ...
                                   theta.x0,theta.y0,theta.z0,theta.w0, ...
                                   sim.h, max(1.0, sim.burnin)); %#ok<ASGLU>
        if cnt_pos < 2
            % không hyperchaos -> coi như "không trúng", tiếp tục
            % (cũng có thể bỏ qua và lấy mẫu khác; ở đây ta chỉ bỏ)
            continue;
        end
    end

    % 3.3 Sinh keystream N mẫu
    ks = simulate_keystream_hyper4d(theta, N, steps_burn, sim);

    if isempty(ks), continue; end
    ks = uint8(ks(:));

    % 3.4 Cho phép thử các dịch thời gian (nếu có)
    is_match = false;
    for s = shifts
        if s > 0
            if numel(ks) <= s, break; end
            ks_s = ks(1+s:end);
            ref  = ks_ref(1:numel(ks_s));
        else
            ks_s = ks(1:N);
            ref  = ks_ref;
        end

        switch match_metric
            case 'RMSE'
                rmse = sqrt(mean( (double(ks_s) - double(ref)).^2 ));
                is_match = (rmse <= tau);
            case 'CORR'
                x = double(ks_s) - mean(double(ks_s));
                y = double(ref)  - mean(double(ref));
                r = sum(x.*y) / sqrt(sum(x.^2)*sum(y.^2) + eps);
                is_match = (r >= corr_min);
            otherwise
                error('Unknown match_metric');
        end

        if is_match
            succ = succ + 1;
            break;
        end
    end
end

q_hat = succ / B;

%==========================================================
% 4) TÍNH K_eff + CI 95%
%==========================================================
if q_hat <= 0
    Delta_q = 0;
else
    Delta_q = -log2(q_hat);
end
K_eff = K_after - Delta_q;

% Wilson CI cho q
alpha = 0.05; z = 1.95996398454005; n = B; phat = q_hat;
den = 1 + z^2/n;
center = (phat + z^2/(2*n))/den;
half = (z/den)*sqrt( phat*(1-phat)/n + z^2/(4*n^2) );
q_lo = max(0, center - half);
q_hi = min(1, center + half);

K_eff_hi = K_after - (q_lo>0)*(-log2(q_lo));
K_eff_lo = K_after - (q_hi>0)*(-log2(q_hi));

%==========================================================
% 5) KẾT QUẢ
%==========================================================
result = struct();
result.K_grid       = K_grid;
result.Delta_sym    = Delta_sym;
result.Delta_shift  = Delta_shift;
result.q_hat        = q_hat;
result.q_CI95       = [q_lo q_hi];
result.K_eff        = K_eff;
result.K_eff_CI95   = [K_eff_lo K_eff_hi];
result.settings     = struct('B',B,'metric',match_metric,'tau',tau,'corr_min',corr_min);

disp('==== KẾT QUẢ ƯỚC LƯỢNG K_eff ====');
fprintf('K_grid            = %.3f bits\n', result.K_grid);
fprintf(' - Δ_sym          = %.3f bits\n', result.Delta_sym);
fprintf(' - Δ_shift        = %.3f bits\n', result.Delta_shift);
fprintf('q_hat             = %.6g  (95%% CI: [%.6g, %.6g])\n', result.q_hat, result.q_CI95(1), result.q_CI95(2));
fprintf('K_eff             = %.3f bits  (95%% CI: [%.3f, %.3f])\n', result.K_eff, result.K_eff_CI95(1), result.K_eff_CI95(2));

end

%==========================================================
% HÀM SINH KEYSTREAM CHO HỆ 4D CỦA BẠN (EULER)
%==========================================================
function ks = simulate_keystream_hyper4d(theta, N, steps_burn, sim)
% theta: struct có A..E, x0..w0
% N: số mẫu cần
% steps_burn: số bước burn-in (mẫu)
% sim: h, quant, mix_alpha, decim

A=theta.A; B=theta.B; C=theta.C; D=theta.D; E=theta.E;
x=theta.x0; y=theta.y0; z=theta.z0; w=theta.w0;
h = sim.h;

% Burn-in
for t=1:steps_burn
    dx = A*(y - x) + C*w;
    dy = D*x - x*z - y;
    dz = x*y - E*z;
    dw = -x - B*w;
    x = x + h*dx;
    y = y + h*dy;
    z = z + h*dz;
    w = w + h*dw;
end

% Sinh dữ liệu (có thể lấy dư để decimate)
M = N * sim.decim;
b = zeros(M,1,'uint8');

% Chuẩn hoá thô các trục (online) không cần biết min/max trước:
% dùng sai phân + trộn phi tuyến + frac + lượng tử byte
x_prev=x; y_prev=y; z_prev=z; w_prev=w;
for k=1:M
    % bước Euler
    dx = A*(y - x) + C*w;
    dy = D*x - x*z - y;
    dz = x*y - E*z;
    dw = -x - B*w;
    x = x + h*dx;
    y = y + h*dy;
    z = z + h*dz;
    w = w + h*dw;

    % sai phân để khử thành phần chậm
    d1 = x - x_prev; d2 = y - y_prev;
    d3 = z - z_prev; d4 = w - w_prev;
    x_prev=x; y_prev=y; z_prev=z; w_prev=w;

    % trộn phi tuyến (determinant-like + cross)
    z_a = d1*(w) - d2*(z);
    z_b = d1*(d2) + d3*(d4);
    mix = z_a + z_b;

    % scale -> frac -> lượng tử byte
    u = sim.mix_alpha * mix;
    frac = u - floor(u);
    if frac < 0, frac = frac - floor(frac); end  % đảm bảo [0,1)
    byte = uint8(floor(min(frac, 1-1e-12) * (sim.quant-1)));

    % bit-mix nhẹ
    b(k) = bitxor(byte, bitxor( bitrol(byte,3), bitrol(byte,5) ));
end

% decimation
if sim.decim > 1
    b = b(1:sim.decim:end);
end

% cắt đúng N
if numel(b) >= N
    ks = b(1:N);
else
    ks = [];
end
end

%==========================================================
% HÀM MŨ LYAPUNOV 4D (BẠN CUNG CẤP) — GIỮ NGUYÊN
%==========================================================
function [LEs,count_pos] = lyap4d_lu(A,B,C,D,E, x0,y0,z0,w0, h, T)
    % Tính 4 mũ Lyapunov (Euler) và số lượng mũ dương
    N = round(T/h);
    X = zeros(4,N+1);
    X(:,1) = [x0;y0;z0;w0];
    for n=1:N
        x=X(1,n); y=X(2,n); z=X(3,n); w=X(4,n);
        dx = A*(y - x) + C*w;
        dy = D*x - x*z - y;
        dz = x*y - E*z;
        dw = -x - B*w;
        X(:,n+1) = X(:,n) + h*[dx;dy;dz;dw];
    end

    jacobian = @(x,y,z,w) [ ...
        1 - h*A,     h*A,         0,        h*C;
        h*(D - z),   1 - h,     -h*x,       0;
        h*y,         h*x,       1 - h*E,    0;
       -h,          -h,         0,         1 - h*B ];

    n0 = max(2, round(0.1*(N+1))); % bỏ transient

    Q = eye(4); S = zeros(4,1); steps = 0;
    for n=n0:(N+1)
        x=X(1,n); y=X(2,n); z=X(3,n); w=X(4,n);
        J = jacobian(x,y,z,w);
        Z = J*Q;
        [Q,R] = qr(Z);
        S = S + log(abs(diag(R)));
        steps = steps + 1;
    end
    LEs = S / (steps*h);
    LEs = sort(LEs,'descend');
    count_pos = sum(LEs > 1e-3);
end

function y = bitrol(x, k)
%BITROL Circular bit rotation left (8-bit)
%   y = bitrol(x, k) dịch trái k bit với wrap-around, trên miền 0–255
    x = uint8(x);      % ép về 8-bit
    k = mod(k, 8);     % chỉ xoay trong [0..7]
    y = bitor( bitshift(x, k), bitshift(x, k-8) );
    y = uint8(bitand(y, 255)); % giữ 8 bit
end
