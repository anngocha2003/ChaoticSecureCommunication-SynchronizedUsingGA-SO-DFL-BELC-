function best = search_entropy_hyper4d()
% Tìm tham số/IC cho entropy gần 8 bits trên MỘT trục (x,y,z,w)
% — random search + refine —
%
% KẾT QUẢ in ra màn hình và trả về struct 'best'

%% 0) Cấu hình hệ & dải tham số
A=1; B=1; C=1.5;
ranges.D  = [20 30];
ranges.E  = [0.5 1.0];
ranges.x0 = [-7 9];
ranges.y0 = [-20 23];
ranges.z0 = [0 43];
ranges.w0 = [-3 4];

% thời gian mô phỏng
h = 1e-3;
burnin = 2.0;      % giây burn-in
T_coarse = 3.0;    % giây đánh giá thô
T_refine = 15.0;   % giây đánh giá tinh (yêu cầu của bạn)

% tìm kiếm
N_coarse = 1000;   % số ứng viên đánh giá thô (tăng sẽ tốt hơn nhưng lâu hơn)
TopK     = 20;     % số ứng viên vào vòng refine
seed     = 123;    % cố định ngẫu nhiên

% tuỳ chọn: phạt tự tương quan để tránh chuỗi ì (0 = bỏ phạt)
lambda_acf = 0.5;  % hệ số phạt (0..1). 0.5 là nhẹ
maxlag = 64;       % xét ACF 1..64

rng(seed);

%% 1) Vòng COARSE: random trong dải + lọc hyperchaos
% Khởi tạo 1 schema thống nhất cho tất cả phần tử
cand = struct( ...
    'D',[], 'E',[], 'x0',[], 'y0',[], 'z0',[], 'w0',[], ...
    'H',zeros(1,4), 'score',-Inf, ...
    'best_axis',NaN, 'bestH',NaN ...
);

coarse_list = repmat(cand, N_coarse, 1);

for n = 1:N_coarse   % (đổi lại parfor sau khi ổn)
    % 1.1 random tham số/IC
    theta = sample_theta(ranges);

    % 1.2 lọc hyperchaos (≥2 LE dương)
    [LEs,cpos] = lyap4d_lu(A,1,C,theta.D,theta.E, ...
                           theta.x0,theta.y0,theta.z0,theta.w0, ...
                           h, max(burnin, 1.0));
    if cpos < 2
        % không hyperchaos -> bỏ vòng lặp, giữ score=-Inf để lọc sau
        continue;
    end

    % 1.3 mô phỏng ngắn để đánh giá entropy
    X = simulate_state(A,1,C,theta.D,theta.E, ...
                       theta.x0,theta.y0,theta.z0,theta.w0, ...
                       h, burnin, T_coarse);

    H = zeros(1,4);
    penalty = zeros(1,4);
    for v = 1:4
        sig = X(v,:);
        H(v) = entropy8_from_signal(sig);
        penalty(v) = acf_penalty(sig, maxlag); % 0..1
    end

    % Chọn trục tốt nhất theo điểm số: H - lambda*penalty
    [score_v, idx] = max(H - lambda_acf*penalty);
    bestH = H(idx);

    % >>> GÁN TRỰC TIẾP THEO CHỈ SỐ (không dùng end+1, không tạo struct mới)
    coarse_list(n).D = theta.D;
    coarse_list(n).E = theta.E;
    coarse_list(n).x0 = theta.x0;
    coarse_list(n).y0 = theta.y0;
    coarse_list(n).z0 = theta.z0;
    coarse_list(n).w0 = theta.w0;
    coarse_list(n).H = H;
    coarse_list(n).score = score_v;
    coarse_list(n).best_axis = idx;
    coarse_list(n).bestH = bestH;
end

% Sau vòng lặp: lọc bỏ các phần tử không hợp lệ (score = -Inf)
valid_idx = ~isinf([coarse_list.score]);
coarse_list = coarse_list(valid_idx);

% loại bỏ entry trống
coarse_list = coarse_list(~arrayfun(@(t) isempty(t.D), coarse_list));
if isempty(coarse_list)
    error('Không tìm thấy ứng viên hyperchaos trong N_coarse=%d. Tăng N_coarse hoặc nới ranges.', N_coarse);
end

% lấy TopK
[~,ord] = sort([coarse_list.score],'descend');
TopK = min(TopK, numel(ord));
top_list = coarse_list(ord(1:TopK));

fprintf('--- COARSE done: giữ %d/%d ứng viên (TopK=%d)\n', numel(top_list), numel(coarse_list), TopK);

%% 2) Vòng REFINE: mô phỏng 15s, đánh giá lại
best = struct('D',[],'E',[],'x0',[],'y0',[],'z0',[],'w0',[], ...
              'axis',[],'H_axis',[],'H_all',[],'penalty',[], ...
              'score',-Inf);

for i=1:TopK
    theta = top_list(i);

    X = simulate_state(A,1,C,theta.D,theta.E, theta.x0,theta.y0,theta.z0,theta.w0, ...
                       h, burnin, T_refine);

    H = zeros(1,4);
    P = zeros(1,4);
    for v=1:4
        sig = X(v,:);
        H(v) = entropy8_from_signal(sig);
        P(v) = acf_penalty(sig, maxlag);
    end
    [score_v, idx] = max(H - lambda_acf*P);

    if score_v > best.score
        best.D = theta.D; best.E = theta.E;
        best.x0 = theta.x0; best.y0 = theta.y0; best.z0 = theta.z0; best.w0 = theta.w0;
        best.axis = idx;
        best.H_axis = H(idx);
        best.H_all = H;
        best.penalty = P;
        best.score = score_v;
    end
end

axes_names = {'x','y','z','w'};
fprintf('\n=== KẾT QUẢ TỐT NHẤT (đánh giá 15s) ===\n');
fprintf('A=1, B=1, C=1.5, D=%.6g, E=%.6g\n', best.D, best.E);
fprintf('IC: x0=%.6g, y0=%.6g, z0=%.6g, w0=%.6g\n', best.x0,best.y0,best.z0,best.w0);
fprintf('Trục tốt nhất: %s  | Entropy=%.4f bits (max 8)\n', axes_names{best.axis}, best.H_axis);
fprintf('Entropy từng trục: [x=%.4f, y=%.4f, z=%.4f, w=%.4f]\n', best.H_all);
fprintf('Penalty ACF từng trục (0 tốt, 1 xấu): [%.3f, %.3f, %.3f, %.3f]\n', best.penalty);

end

%% ================== HÀM PHỤ ==================
function theta = sample_theta(r)
    theta.D  = r.D(1)  + rand*(r.D(2)-r.D(1));
    theta.E  = r.E(1)  + rand*(r.E(2)-r.E(1));
    theta.x0 = r.x0(1) + rand*(r.x0(2)-r.x0(1));
    theta.y0 = r.y0(1) + rand*(r.y0(2)-r.y0(1));
    theta.z0 = r.z0(1) + rand*(r.z0(2)-r.z0(1));
    theta.w0 = r.w0(1) + rand*(r.w0(2)-r.w0(1));
end

function X = simulate_state(A,B,C,D,E, x0,y0,z0,w0, h, Tburn, Teval)
    % Euler rời rạc, trả về ma trận 4×N (sau burn-in)
    steps_burn = round(Tburn/h);
    steps_eval = round(Teval/h);

    x=x0; y=y0; z=z0; w=w0;

    % burn-in
    for t=1:steps_burn
        dx = A*(y - x) + C*w;
        dy = D*x - x*z - y;
        dz = x*y - E*z;
        dw = -x - B*w;
        x = x + h*dx;
        y = y + h*dy;
        z = z + h*dz;
        w = w + h*dw;
    end

    % thu tín hiệu
    X = zeros(4, steps_eval);
    for k=1:steps_eval
        dx = A*(y - x) + C*w;
        dy = D*x - x*z - y;
        dz = x*y - E*z;
        dw = -x - B*w;
        x = x + h*dx;
        y = y + h*dy;
        z = z + h*dz;
        w = w + h*dw;
        X(:,k) = [x;y;z;w];
    end
end

function H = entropy8_from_signal(sig)
    % Tính Shannon entropy (8-bit) của 1 trục
    % Chuẩn hoá min-max -> [0,1], rồi lượng tử 256 mức
    sig = sig(:).';
    smin = min(sig); smax = max(sig);
    if smax==smin
        H = 0; return;
    end
    u = (sig - smin)/(smax - smin);
    bins = 256;
    edges = linspace(0,1,bins+1);
    counts = histcounts(u, edges);
    p = counts / sum(counts);
    p = p(p>0);
    H = -sum(p.*log2(p));
end

function p = acf_penalty(sig, maxlag)
    % Phạt tự tương quan: p in [0,1], 0 là tốt (ít tự tương quan)
    x = sig(:) - mean(sig);
    n = numel(x);
    maxr = 0;
    for lag=1:maxlag
        r = sum( x(1:n-lag).*x(1+lag:n) ) / (sum(x.^2) + eps);
        maxr = max(maxr, abs(r));
    end
    % ánh xạ về [0,1]
    p = min(1, max(0, maxr));
end

function [LEs,count_pos] = lyap4d_lu(A,B,C,D,E, x0,y0,z0,w0, h, T)
    % Tính 4 mũ Lyapunov (Euler) và số lượng mũ dương
    N = round(T/h);
    X = zeros(4,N+1);
    X(:,1) = [x0;y0;z0;w0];
    for n=1:N
        x=X(1,n); y=X(2,n); z=X(3,n); w=X(4,n);
        dx = A*(y - x) + C*w;
        dy = D*x - x*z - y;
        dz = x*y - E*z;
        dw = -x - B*w;
        X(:,n+1) = X(:,n) + h*[dx;dy;dz;dw];
    end

    jacobian = @(x,y,z,w) [ ...
        1 - h*A,     h*A,         0,        h*C;
        h*(D - z),   1 - h,     -h*x,       0;
        h*y,         h*x,       1 - h*E,    0;
       -h,          -h,         0,         1 - h*B ];

    n0 = max(2, round(0.1*(N+1))); % bỏ transient

    Q = eye(4); S = zeros(4,1); steps = 0;
    for n=n0:(N+1)
        x=X(1,n); y=X(2,n); z=X(3,n); w=X(4,n);
        J = jacobian(x,y,z,w);
        Z = J*Q;
        [Q,R] = qr(Z);
        S = S + log(abs(diag(R)));
        steps = steps + 1;
    end
    LEs = S / (steps*h);
    LEs = sort(LEs,'descend');
    count_pos = sum(LEs > 1e-3);
end
