function results = analyze_hyper4d()
    % ===== Tham số hệ =====
    A=1; B=1; C=1.5; D=26; E=0.7;
    x0 = 0.15; y0 = 0.25; z0 = -0.5; w0 = -0.25;
    % x0 = 2; y0 = 2; z0 = 2; w0 = 2;
    h=0.001; T=10;
    N = round(T/h);

    % ===== Mô phỏng hệ =====
    X = zeros(4,N+1);
    X(:,1) = [x0;y0;z0;w0];
    for n=1:N
        x=X(1,n); y=X(2,n); z=X(3,n); w=X(4,n);
        dx = A*(y - x) + C*w;
        dy = D*x - x*z - y;
        dz = x*y - E*z;
        dw = -x - B*w;
        X(:,n+1) = X(:,n) + h*[dx;dy;dz;dw];
    end

    names = {'x','y','z','w'};
    bins = 256; % 8-bit
    
    %% ===== 1. Tính entropy =====
    entropy_vals = zeros(1,4);
    for var = 1:4
        signal = X(var,:);
        signal = (signal - min(signal)) / (max(signal) - min(signal));
        edges = linspace(0,1,bins+1);
        [counts,~] = histcounts(signal, edges);
        p = counts / sum(counts);
        p_nonzero = p(p>0);
        entropy_vals(var) = -sum(p_nonzero .* log2(p_nonzero));
    end

    %% ===== 2. Correlation (tự tương quan giữa các biến) =====
    corr_matrix = corrcoef(X');  % hệ số tương quan Pearson

    %% ===== 3. Histogram uniformity =====
    hist_uniformity = zeros(1,4);
    for var = 1:4
        signal = X(var,:);
        signal = (signal - min(signal)) / (max(signal) - min(signal));
        edges = linspace(0,1,bins+1);
        counts = histcounts(signal, edges);
        p = counts / sum(counts);
        hist_uniformity(var) = sum(p.^2); % càng nhỏ càng đồng đều
    end

    %% ===== 4. Key sensitivity (so sánh x0 vs x0+delta) =====
    delta = 1e-6; % thay đổi rất nhỏ
    X2 = simulate_system([x0+delta,y0,z0,w0],A,B,C,D,E,h,N);
    diff_traj = mean(abs(X(:)-X2(:))); % sai khác trung bình

    %% ===== 5. Xuất kết quả =====
    for i=1:4
        fprintf('Entropy(%s) = %.4f / %d bits\n', names{i}, entropy_vals(i), log2(bins));
        fprintf('Histogram uniformity(%s) = %.6f\n', names{i}, hist_uniformity(i));
    end
    fprintf('Key sensitivity (Δx0=1e-6) → mean diff = %.6f\n', diff_traj);

    results.entropy = entropy_vals;
    results.corr_matrix = corr_matrix;
    results.hist_uniformity = hist_uniformity;
    results.key_sensitivity = diff_traj;

    % Sau khi bạn đã mô phỏng X với khóa gốc:
    stats = extra_stats(X,256);
    fprintf('\n--- ACF max (|lag|>0) ---\n'); disp(stats.acf_max)
    fprintf('--- Chi2 p-values (gần 1 là tốt) ---\n'); disp(stats.chi2_p)
    
    % Key sensitivity trên tất cả trục
    delta = 1e-6;
    X2 = simulate_system([2+delta,2,2,2], 1,1,1.5,26,0.7, 0.001, round(10/0.001));
    avals = avalanche_byte(X, X2);
    for v = 1:4
        fprintf('Avalanche (%s-axis) = %.2f%% (mục tiêu ~50%%)\n', names{v}, avals(v)*100);
    end

    %% Xuất dữ liệu ra Excel
    T = array2table(X', 'VariableNames', names);
    writetable(T, 'hyper4d_states_1.xlsx', 'WriteMode','overwrite');
    fprintf('>> Dữ liệu hệ (x,y,z,w) đã lưu vào hyper4d_states_full.xlsx\n');
end

%% Hàm phụ mô phỏng lại hệ với điều kiện ban đầu khác
function X = simulate_system(init,A,B,C,D,E,h,N)
    X = zeros(4,N+1);
    X(:,1) = init(:);
    for n=1:N
        x=X(1,n); y=X(2,n); z=X(3,n); w=X(4,n);
        dx = A*(y - x) + C*w;
        dy = D*x - x*z - y;
        dz = x*y - E*z;
        dw = -x - B*w;
        X(:,n+1) = X(:,n) + h*[dx;dy;dz;dw];
    end
end
%% ACF tối đa
function stats = extra_stats(X, bins)
    if nargin<2, bins=256; end
    names = {'x','y','z','w'};
    for v=1:4
        sig = X(v,:);
        % Chuẩn hoá 0..1 và lượng tử 8-bit
        u = (sig - min(sig)) / (max(sig)-min(sig) + eps);
        q = min(255,floor(u*256));  % 0..255

        % --- ACF max (loại lag=0)
        x = double(q) - mean(double(q));
        n = numel(x);
        denom = sum(x.^2)+eps;
        maxlag = 128;
        rmax = 0;
        for lag=1:maxlag
            r = sum( x(1:n-lag).*x(1+lag:n) ) / denom;
            rmax = max(rmax, abs(r));
        end
        stats.acf_max(v) = rmax;

        % --- Chi-square test so với đều
        counts = histcounts(q, 0:256);
        expected = numel(q)/bins;
        chi2 = sum( (counts-expected).^2 / (expected+eps) );
        dof = bins-1;
        pval = 1 - chi2cdf(chi2, dof);
        stats.chi2(v) = chi2;
        stats.chi2_p(v) = pval;

        % --- Entropy (tham khảo)
        p = counts/sum(counts);
        p = p(p>0);
        stats.entropy(v) = -sum(p.*log2(p));
    end
    stats.names = names;
    stats.corr_axes = corrcoef(X'); % tương quan giữa các trục
end
%% Avalanche
function aval = avalanche_byte(X1, X2)
    % X1, X2: ma trận 4×N trạng thái sau mô phỏng (cùng chiều)
    % Tính avalanche cho cả 4 trục (x,y,z,w)
    aval = zeros(1,4);
    for v = 1:4
        q1 = quantize8(X1(v,:));
        q2 = quantize8(X2(v,:));
        % Đếm bit khác nhau từng byte
        diffs = bitxor(uint8(q1), uint8(q2));
        % Đếm số bit 1 trong mỗi byte
        ones_per_byte = arrayfun(@(b) sum(bitget(b,1:8)), diffs);
        aval(v) = mean(ones_per_byte)/8; % kỳ vọng ~0.5
    end
end

function q = quantize8(sig)
    u = (sig - min(sig)) / (max(sig)-min(sig) + eps);
    q = uint8(min(255, floor(u*256)));
end

