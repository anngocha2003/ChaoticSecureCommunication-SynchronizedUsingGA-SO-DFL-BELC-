import serial
import csv

# Mở cổng Serial (Thay COM3 bằng cổng Serial của bạn)
ser = serial.Serial('COM10', 9600)  

# Mở file CSV để ghi
with open('pid.csv', 'w', newline='') as file:
    writer = csv.writer(file)
    
    while True:
        data = ser.readline().decode().strip()  # Đọc dữ liệu từ Serial
        print(data)  # Hiển thị dữ liệu trên màn hình
        writer.writerow([data])  # Ghi dữ liệu vào file CSV
